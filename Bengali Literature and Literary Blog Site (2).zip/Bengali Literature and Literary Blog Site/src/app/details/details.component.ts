import { Component, OnInit, ElementRef, ViewChild } from '@angular/core';
import { NgbModal } from '@ng-bootstrap/ng-bootstrap';
import html2canvas from 'html2canvas';
import { jsPDF } from 'jspdf';
import { NgbModalRef } from '@ng-bootstrap/ng-bootstrap';
import { ToastrService } from 'ngx-toastr';
@Component({
  selector: 'app-details',
  templateUrl: './details.component.html',
  styleUrls: ['./details.component.css']
})
export class DetailsComponent implements OnInit {
  dataArr: any = [];
  displayColumnArr: any = [];
  key: string = 'pname'; //set default
  reverse: boolean = false;
  private modalRef: NgbModalRef;
  @ViewChild('content', { 'static': true }) content:ElementRef;
  constructor(private modalService: NgbModal,private toastr: ToastrService) { }
  
  ngOnInit(): void {
    //if localstorage available then is will get data first
    if ("form" in localStorage) {
      let data = localStorage.getItem('form');
      this.dataArr = JSON.parse(data);
    }
    //if push the data in display column array for display column
    this.displayColumnArr.push('pid','pname','action');
 }

 // sort column ascending or decending
 // one params field name
 sort(key){
  this.key = key;
  this.reverse = !this.reverse;
}

 // export pdf convert html to pdf
 exportAsPDF() {
   const div = document.getElementById('content');
    const options = {
      background: 'white',
      scale: 3
    };

    html2canvas(div, options).then((canvas) => {

      var img = canvas.toDataURL("image/PNG");
      var doc = new jsPDF('l', 'mm', 'a4');

      // Add image Canvas to PDF
      const bufferX = 5;
      const bufferY = 5;
      const imgProps = (<any>doc).getImageProperties(img);
      const pdfWidth = doc.internal.pageSize.getWidth() - 2 * bufferX;
      const pdfHeight = (imgProps.height * pdfWidth) / imgProps.width;
      doc.addImage(img, bufferX, bufferY, pdfWidth, pdfHeight, undefined);

      return doc;
    }).then((doc) => {
      doc.save('productList.pdf');  
    });
}

 // delete confirmation popup open
 // one params popup
 popupOpen(confirmpopup) {
  this.modalRef = this.modalService.open(confirmpopup,  { centered: true , size: 'md' })
 }

 // column add for display field in table
 // one params field name
 columnAdd(field) {
      let index = this.displayColumnArr.indexOf(field);
      if(index !== -1) {
        this.displayColumnArr.splice(index,1);
      } else {
        this.displayColumnArr.push(field);
      }
 }

 // delete data using product id
 // two params product id , popup
 delete(pid,confirmpopup) {
   let index = this.dataArr.findIndex(p => p.pid == pid);
  this.dataArr.splice(index,1);
  if(this.dataArr.length == 0) {
    localStorage.removeItem('form');
  } else {
    localStorage.setItem('form',JSON.stringify(this.dataArr));
  }
  this.modalRef.close();
  this.toastr.success('Product Deleted Successfully!', 'Success!');
}
 

}
