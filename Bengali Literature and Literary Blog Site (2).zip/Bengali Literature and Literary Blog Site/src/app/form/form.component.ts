import { Component, OnInit } from '@angular/core';
import { FormModel } from './form.model';
import { Router, ActivatedRoute } from '@angular/router';
import { ToastrService } from 'ngx-toastr';

@Component({
  selector: 'app-form',
  templateUrl: './form.component.html',
  styleUrls: ['./form.component.css']
})
export class FormComponent implements OnInit {
  formArray = [];
  pid: any;
  buttonName: any = 'Insert';
  newImage: any = false;
  form = new FormModel();
  constructor(private route: Router,private activeroute: ActivatedRoute,private toastr: ToastrService) { }
  imageSrc: any;
  ngOnInit(): void {
    // product id get from route params
    this.pid = this.activeroute.snapshot.params.id;
    // if product id is available then it will fill data in form
    if(this.pid) {
        let data = localStorage.getItem('form');
        this.formArray = JSON.parse(data);
        let index = this.formArray.findIndex(p => p.pid == this.pid);
        this.form = this.formArray[index];
        this.buttonName = 'Update';
    }
  }

  // redirect to list 
  clear() {
    this.route.navigate(['/']);
  }

  // add and update data after form submit and if is valid
  submit(form) {
    form.submitted = false;
    // create unique and random string generate
    this.form.pid = Date.now().toString(36) + Math.random().toString(36).substr(2);
    if ("form" in localStorage) {
      let data = localStorage.getItem('form');
      this.formArray = JSON.parse(data);
    }
  
    if(this.pid) {
       // if product id is getting then update data from array 
      let index = this.formArray.findIndex(p => p.pid == this.pid);
      this.formArray.splice(index,1,this.form);
      this.toastr.success('Product Updated Successfully!', 'Success!');
    } else {
       // if product id not getting then add data from array 
      this.formArray.push(this.form);
      this.toastr.success('Product Added Successfully!', 'Success!');
    }
    // added update data in localstorage
    localStorage.setItem('form',JSON.stringify(this.formArray));
    this.route.navigate(['/']);
    }

  // when image will upload that time it checking and convert into base64
  fileChangeEvent(fileInput: any) {
    var file = fileInput.dataTransfer ? fileInput.dataTransfer.files[0] : fileInput.target.files[0];
    let img = new Image();
   
    img.src = window.URL.createObjectURL(fileInput.target.files[0]);
    if(fileInput.target.files[0].type !== 'image/png' && fileInput.target.files[0].type !== 'image/jpg' && fileInput.target.files[0].type !== 'image/jpeg') {
      this.toastr.error('Please upload image!', 'Error!');
    }
    else if (fileInput.target.files[0].size > 1048576) {
      this.toastr.error('Image upload Maximum size 1 mb!', 'Error!');
    } else if(fileInput.target.files[0].size < 10000) {
      this.toastr.error('Image upload Mimium size 10 kb!', 'Error!');
    } else {
      var reader = new FileReader();
      this.newImage = true;
      reader.onload = this._handleReaderLoaded.bind(this);
      reader.readAsDataURL(file);
    }
  }

  // when image will upload that time its store in form object
  _handleReaderLoaded(e) {
    let reader = e.target;
    this.imageSrc = reader.result;
    this.form.image =  this.imageSrc;
  }


}
