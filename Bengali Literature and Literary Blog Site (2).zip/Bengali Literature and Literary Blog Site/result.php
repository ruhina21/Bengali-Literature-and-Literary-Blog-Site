  <!DOCTYPE html>
  <html>
  <head>
    <title>Result</title>
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
      <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.1/css/all.min.css">
      <link rel="stylesheet" href="/css/bootstrap-grid.min.css">
      <link rel="stylesheet" href="explr.css">
      <link rel="preconnect" href="https://fonts.gstatic.com">
        <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.1/css/all.min.css">
      <link href="https://fonts.googleapis.com/css2?family=Big+Shoulders+Stencil+Text:wght@700&display=swap" rel="stylesheet">
      <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.1.3/css/bootstrap.min.css" integrity="sha384-MCw98/SFnGE8fJT3GXwEOngsV7Zt27NXFoaoApmYm81iuXoPkFOJwJ8ERdknLPMO" crossorigin="anonymous">
      <link rel="preconnect" href="https://fonts.gstatic.com">
<link href="https://fonts.googleapis.com/css2?family=Abril+Fatface&display=swap" rel="stylesheet">
  </head>
  <body>



<table style="border: 2px solid #641016;" class=" text-center">
                <tr class="mx-4 ml-4 my-4">
                   
                    <th class="mr-4 ml-4 my-4">Name</th>
                    <th class="mr-4 ml-4 my-4">Writer</th>
                    <th class="mr-4 ml-4 my-4">Category</th>
                    <th class="corner wideRow">Description</th>
                    <th class="mr-4 ml-4 my-4">Link</th>
                </tr>

      <!-- populate table from mysql database -->
                <?php while($row = mysqli_fetch_array($search_result)):?>
                <tr class="mr-4 ml-4 my-4">
                    
                    <td style="color: Yellow" class="mr-4 ml-4 my-4"><?php echo $row['name'];?></td>
                    <td class="mr-4 ml-4 my-4"><?php echo $row['writer'];?></td>
                    <td class="mr-4 ml-4 my-4"><?php echo $row['category'];?></td>
                     <td class="mr-4 ml-4 my-4"><?php echo $row['description'];?></td>
                      <td class="mr-4 ml-4 my-4"><?php echo $row['link'];?></td>
                </tr>
                <?php endwhile;?>
            </table>
            <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
  </body>
  </html>
 