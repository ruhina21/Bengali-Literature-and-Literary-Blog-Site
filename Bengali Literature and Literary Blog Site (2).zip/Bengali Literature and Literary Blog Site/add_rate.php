
<?php
error_reporting(0);
?>
<!DOCTYPE html>
<html>
<head>
  <br><br><br><br><br><br>
  <style >
    .section-title{
       font-family: 'Big Shoulders Stencil Text', cursive;
       color: #641016;
    }

  </style>
</head>


</html>

  <!DOCTYPE html>
  
  <head>
    <title>maloti</title>
     <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=YES">
      <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.1/css/all.min.css">
      <link rel="stylesheet" href="/css/bootstrap-grid.min.css">
      <link rel="stylesheet" href="explr.css">
      <link rel="preconnect" href="https://fonts.gstatic.com">
        <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.1/css/all.min.css">
      <link href="https://fonts.googleapis.com/css2?family=Big+Shoulders+Stencil+Text:wght@700&display=swap" rel="stylesheet">
      <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.1.3/css/bootstrap.min.css" integrity="sha384-MCw98/SFnGE8fJT3GXwEOngsV7Zt27NXFoaoApmYm81iuXoPkFOJwJ8ERdknLPMO" crossorigin="anonymous">
      <link href="https://fonts.googleapis.com/css2?family=Abril+Fatface&display=swap" rel="stylesheet">
<style>
  a{
    color: yellow;
  }
  a:hover{
    color:black;
     transform:scale(1.1);
  
  }
  .nav-item{
  font-family: 'Abril Fatface', cursive;
}

.media-body img{
    
    height: 70px;
    width: 70px;
    border-radius: 50%;
    } 
.media-body{}

.btn {
  background-color: #641016;
  border: none;
  color: white;
  padding: 12px 30px;
  cursor: pointer;
  font-size: 20px;
}

/* Darker background on mouse-over */
.btn:hover {
  background-color: orange;
}
</style>
  </head>
  <body style="background-color:black" >
    <?php 

$localhost = "localhost"; #localhost
$dbusername = "root"; #username of phpmyadmin
$dbpassword = "";  #password of phpmyadmin
$dbname = "ruhina";  #database name
 
#connection string

$conn = mysqli_connect($localhost,$dbusername,$dbpassword,$dbname);

$localhost = "localhost"; #localhost
$dbusername = "root"; #username of phpmyadmin
$dbpassword = "";  #password of phpmyadmin
$dbname = "ruhina";  #database name
 
#connection string

$conn2 = mysqli_connect($localhost,$dbusername,$dbpassword,$dbname);

?>
      <?php session_start(); ?>
      <?php echo $_SESSION['user_name']; ?>
      <?php
$bookwriter=$_SESSION['user_name'];
$query2=mysqli_query($conn2,"SELECT * from regform WHERE username='$bookwriter'");
$stl= mysqli_fetch_array($query2);
?>
 
  <div class="container">
    <header class="mx-0 " >
      <nav class="navbar navbar-expand-md navbar-dark fixed-top">
    <a class="navbar-brand" href="http://localhost/project/projecting.php">
  <img src="maloti.jpg" style="width:100px" class="rounded-circle"alt="Maloti">
      </a>
      <div class="collapse navbar-collapse" id="navbarNav">

    <ul class="navbar-nav ">

      <li class="nav-item ">
       <button class="btn btn-lg bg-warning mr-3 " > <a class="nav-link" style="color: #641016" href="http://localhost/project/explore.php">AUTHOR LIST<span class="sr-only">(current)</span></a></button>
      </li>
     <li class="nav-item ">
       <button class="btn btn-lg bg-warning mr-3 " > <a class="nav-link" style="color: #641016" href="http://localhost/project/Booklist.php">BOOK LIST</a></button>
      </li>
      <li class="nav-item active font-weight-bolder">
        <button class="btn btn-lg  " style="font-weight: bolder ;background-color: yellow"><a class="nav-link" href="#" style="color: yellow;background-color: #641016">BLOG SECTION</a></button>
      </li>

     
    </ul>
  </div>
  
  </nav>
   </header>
<main>
  <br><br><br>
  <section id="Blog">
    <div class="section-title py-3">
        <h1 class="text-center" style="text:#c30c02">Upload Your Blog</h1>
        </div>

<form method="post" enctype="multipart/form-data" class="bg-warning " action="add_rate.php">
    <label  class="mx-4 my-4"> Title :</label>
    <input type="text" name="title" class="ml-4 my-4"><br><br>

    <input type="hidden" name="author" value="<?php echo $_SESSION['user_name']; ?>">
    <label  class="mx-4 my-4" style="font-weight: bold" >File Upload :</label><br>
    <input  class="mx-4 my-4"type="File" name="file">
    <input type="submit" name="submit"  class="ml-4 my-4">
 
 
</form>
 

 
<br><br><br>


 
  </section>
<div class="section-title py-3">
        <h1 class="text-center " >BLOGS</h1>
        </div>
<?php 

if ($_SERVER["REQUEST_METHOD"] == "POST")
{
   $file=$_FILES["file"]["name"];
  $tmp_name=$_FILES["file"]["tmp_name"];
  $path="uploads/".$file;
  $file1=explode(".",$file);
  $ext=$file1[1];
  $allowed=array("jpg","png","gif","pdf","wmv","pdf","zip");
  $title=$_POST['title'];
    $author = $_POST["author"];
     
  if(in_array($ext,$allowed))
  {
 move_uploaded_file($tmp_name,$path);

  $sql = "INSERT into blobb(title,author,file) VALUES('$title','$author','$file')";
   if(mysqli_query($conn,$sql)){
 
    echo " ";
    }
    else{
        echo "  ";
    }

  
}
}
if ($_SERVER["REQUEST_METHOD"] == "POST")
{
     $blog=$_POST['blog'];
     $comment = $_POST["comment"];
     $me = $_POST['me'];
  $sql7 = "INSERT into commenttable(blog,comment,me) VALUES('$blog','$comment','$bookwriter')";
   if(mysqli_query($conn,$sql7)){
 
    echo " ";
    }
    else{
        echo " ";
    }
}

$query=mysqli_query($conn,"SELECT * from  blobb INNER JOIN regform ON blobb.author=regform.username Order by date");
$rowcount=mysqli_num_rows($query);

for($i=0;$i<$rowcount;$i++)
{
  $row=mysqli_fetch_array($query);


?>
<div class="media  p-3 mt-3 text-white " style="border-style: outset; border-color: yellow ;border-collapse: separate;">
                    
                   <div  class="media-body"  >
 
        <div class="col margin-auto"   >
         <div class="row"> 
          <div class=" mx-4">
         <?php echo "<img src='images/".$row['image']."'  >";?>
       </div>
       <div class=" mt-3px ">
   <h3 class="py-auto margin-auto"><?php echo $row["title"] ;?></h3> <h5 style="color: yellow"> Author : <?php echo $row["author"] ;?><br></h5>

   
    <button class="btn"><i class="fa fa-download"></i> <a href="uploads/<?php echo $row["file"] ?>"><?php echo $row["file"] ?></a></button><h4 style="font-size: 15px;color: grey"><?php echo $row["date"]; ?></h4>
 </div></div>
  

    </div>
   <?php
   $volvo=$row['title'];
   ?>
 
              
 <div>
  <div class="row">
    
     <form action="add_rate.php" enctype="multipart/form-data"  method="post" class="comment-form">
    <input type="hidden" name="blog" value="<?php echo $row['title']; ?>">
 
    <input type="hidden" name="me" value="<?php echo $_SESSION['user_name']; ?>">
   <span style="margin-left: 20px;margin-right: 0px"> <?php echo "<img src='images/".$stl['image']."'  >";?></span>
     <input type="text" name="comment" placeholder="Leave a comment...." class="ml-4 my-4" style="width: 500px;height: 70px"> <button name="submit">comment</button><br>
   </form>
   
<div class="container-fluid">
    
<button class="btn btn-info" type="button" data-toggle="collapse" data-target="#footwear" aria-expanded="false" aria-controls="footwear">
View All Comments
</button>
<br><br>
<?php
$query9=mysqli_query( $conn,"SELECT * from commenttable INNER JOIN regform ON commenttable.me=regform.username WHERE blog='$volvo'");
$rowcount2=mysqli_num_rows($query9);

  for($j=0;$j<$rowcount2;$j++)
{
  $row=mysqli_fetch_array($query9);


?>
<div class="collapse" id="footwear">
<div class="row">
        <div class=" mx-4px"   >
          <div class="row">
          <div class="mx-4">
         <?php echo "<img src='images/".$row['image']."'  >";?>
       </div>
   <div class=" mt-3px ">
  
 <b><?php echo $row["me"]; ?></b><br>
 <?php echo $row["comment"]; ?>

  <p style="font-size: 15px;color: grey"><?php echo $row["date"]; ?></p>
</div>
</div>
    </div>            
 </div>
</div>

<?php
}
?>
</div>

  </div>
  

  </div>
 </div>

</div>
<?php
  }
  ?>
</div>

</div>





</main>
  

  <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js" integrity="sha384-DfXdz2htPH0lsSSs5nCTpuj/zy4C+OGpamoFVy38MVBnE+IbbVYUew+OrCXaRkfj" crossorigin="anonymous"></script>
            <script src="https://cdn.jsdelivr.net/npm/bootstrap@4.5.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-ho+j7jyWK8fNQe+A12Hb8AhRq26LrZ/JpcUGGOn+Y7RsweNrtN/tE3MoK7ZeZDyx" crossorigin="anonymous"></script>
            <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js" integrity="sha384-DfXdz2htPH0lsSSs5nCTpuj/zy4C+OGpamoFVy38MVBnE+IbbVYUew+OrCXaRkfj" crossorigin="anonymous"></script>
            <script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.1/dist/umd/popper.min.js" integrity="sha384-9/reFTGAW83EW2RDu2S0VKaIzap3H66lZH81PoYlFhbGU+6BZp6G7niu735Sk7lN" crossorigin="anonymous"></script>
            <script src="https://cdn.jsdelivr.net/npm/bootstrap@4.5.3/dist/js/bootstrap.min.js" integrity="sha384-w1Q4orYjBQndcko6MimVbzY0tgp4pWB4lZ7lr30WKz0vr/aWKhXdBNmNb5D92v7s" crossorigin="anonymous"></script>
  </body>

</html>



   