

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="utf-8">
  <title>Sign up</title>
   <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.1.3/css/bootstrap.min.css" integrity="sha384-MCw98/SFnGE8fJT3GXwEOngsV7Zt27NXFoaoApmYm81iuXoPkFOJwJ8ERdknLPMO" crossorigin="anonymous">
  <style >
    .demo{
  color: red;
}
.container
{
color: white;
}


body{


}
.section-title{
  font-family: 'Big Shoulders Stencil Text', cursive;
}
.hr-style{
  border:5px dotted white;
  border-bottom: none;
  width: 50px;
}
.btn{
  background-color: #000000;

}

.btn:hover{
  transform:scale(2.1);
  box-shadow:2px 6px 5px #970900;
}
.nav-link{
  margin:10px;
  border-radius: 5px;
  transition: .4s;
}
.nav-link:hover{
  background: #660000;
  outline-offset: white;
  transform: scale(1.1);
}
.navbar{
  padding: 1% 10%;
  background-color: rgba(400, 100, 100, 0.2);

}
.checked
{
color:red;
}
.unchecked
{
color:black;
}
header{
  background-image:url(https://encrypted-tbn0.gstatic.com/images?q=tbn%3AANd9GcQa3PHLzoq9sEpp1hSSo_uK0dJ7Nn4vpEHrHQ&usqp=CAU);

  background-repeat: no-repeat;
  background-position: center;


  background-size: cover;

  font-family: 'Big Shoulders Stencil Text', cursive;
}
h1,h2,h3,h4,p{
  font-family: 'Big Shoulders Stencil Text', cursive;
}
.banner-container{
height: 70vh;


}

img{
  float: left;
}
.login-page{
  width: 500px;
  padding: 10% 0 0;
  margin: auto;
}

.form{
  position: relative;
  z-index: 1;
  background: #ADADAD;
  max-width: 500px;
  margin: 0 auto 100px;
  padding: 50px;
  text-align: center;

}

.form input{
  font-family: "Roboto", sans-serif;
  outline: 1;
  background: #f2f2f2;
  width: 100%;
  border: 0;
  margin: 0 0 15px;
  padding: 15px;
  box-sizing: border-box;
  font-size: 14px;
}

.form button{
  font-family: "Roboto", sans-serif;
  text-transform: uppercase;
  outline: 0;
  background: yellow;
  width: 100%;
  border: 0;
  padding: 15px;
  color: black;
  font-size: 14px;
  cursor: pointer;

}
.hey:hover
{
    transform: scale(1.1);
}
.form button:hover, .form button:active{
  background: #641016;
  color: white;
}

.form .message{
  margin: 15px 0 0;
  color: #333333;
  font-size: 18px;
}

.form .message a{
  color: blue;
  text-decoration: none;
}

.form .register-form{
  display: none;
}
.row
{
  opacity: 0.7;
}
.row:hover{
  opacity: 1;
}

  </style>
</head>
<?php

  session_start();
  $db = new mysqli("localhost","root","","ruhina");

  if(isset($_POST['submit'])){
    $username = $_POST['username'];
    $password = $_POST['password'];
    $email = $_POST['email'];
     $age = $_POST['age'];
      $profession = $_POST['profession'];
      $mobile = $_POST['mobile'];
 $image = $_FILES['image']['name'];
    $image_text = mysqli_real_escape_string($db,$_POST['image_text']);
        $target = "images/".basename($image); 

    $query = "INSERT INTO regform(username, password,email,age,profession,mobile,image,image_text) VALUES ('$username' , '$password', '$email','$age','$profession','$mobile','$image','$image_text')";
      mysqli_query($db, $query);

    if (move_uploaded_file($_FILES['image']['tmp_name'], $target)) {
      $msg = "Image uploaded successfully";
    }else{
      $msg = "Failed to upload image";
    }
  }
    $result = mysqli_query($db, "SELECT * FROM images");
  if(isset($_POST['login'])){
    $username = $_POST['lusername'];
    $password = $_POST['lpassword'];

    $mysqli = new mysqli("localhost","root","","ruhina");
    $result = $mysqli->query("SELECT * FROM regform WHERE username = '$username' AND password ='$password' ");
    $row = $result->fetch_assoc();

    if($row['username'] == $username && $row['password'] == $password)
    {
      $message = "Login successful.!";
   header('Location: http://localhost/project/projecting.php');
  
      echo "<script type='text/javascript'>alert('$message');</script>";
       $_SESSION['user_name'] = $username;
       
    }
    else{
      $message1 = "Login Unsuccessful.!";
      echo "<script type='text/javascript'>alert('$message1');</script>";
    }
     }

?>
<body style="background-image: url('bok.jpg');">
  <br><br><br><br><br><br><br>
  <div class="container " style="justify-content: center">
    <div class="row">
      <div class="col-3">
        <br><br>
 <img src="maloti.jpg" style="width:300px ;" class="rounded-circle" >
 </div>
 <div class="col-5">
  <div class="login-page">
   
    <div class="form" style="background-color: #000000;">
      <form action="reg.php" enctype="multipart/form-data" method="POST" class="register-form">
        <input type="text" name="username" placeholder="user name">
          <input type="text" name="age" placeholder="age"> 
          <input type="text" name="profession" placeholder="profession"> 
          <input type="text" name="mobile" placeholder="contact no.">
        <input type="password" name="password" placeholder="password">
        <input type="text" name="email" placeholder="email id">
          <input type="hidden" name="size" value="1000000">
         <input style="background-color: brown" type="file" name="image" > 
           <textarea 
        id="text" 
        cols="40" 
        rows="4" 
        name="image_text" 
        placeholder="Say something about You..."></textarea>
        <button name="submit">Create</button>
        <p class="message">Already Registered?<a href="#">Login</a></p>
      </form>

      <form action="reg.php" method="post" class="login-form">
        <input type="text" name="lusername" placeholder="user name">
        <input type="password" name="lpassword" placeholder="password">
        <button name="login">Log in</button>
        <p class="message">Not Registered?<a href="#" style="color: green">Register</a></p>
      </form>
      </div>
      </div>
    </div>
  </div>
</div>
  <script src='http://code.jquery.com/jquery-3.3.1.min.js'></script>
  <script src="js/jquery-3.3.1.min.js"></script>
  <script src="js/popper.min.js"></script>
  <script src="js/bootstarp.min.js"></script>
  <script src="js/custom.js"></script>

  <script>
    $('.message a').click(function(){
      $('form').animate({height: "toggle",opacity: "toggle"}, "slow");
    });
  </script>

</body>
</html>