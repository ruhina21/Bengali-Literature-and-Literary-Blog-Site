<?php
session_start();
?>
<div>
<h1>Your Profile</h1>
<div class="container">
	<div class="row">
		<div col-6>
	<div class="profile">
	Name : <?php echo $_SESSION['user_name'];?><br>
	Age: <?php echo $_SESSION['age_s'];?><br>
	Profession: <?php echo $_SESSION['profession_s'];?><br>
	E-mail: <?php echo $_SESSION['email_s'];?><br>
	Mobile: <?php echo $_SESSION['mobile_s'];?><br>
<button><a href="editor.php">Update your Profile</a></button>
</div>
<div class="col-6">
	<img src="<?php echo $_SESSION['file'];?>">
</div>
</div>
</div>
</div>
