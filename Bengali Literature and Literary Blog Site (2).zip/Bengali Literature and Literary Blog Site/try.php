<!DOCTYPE html>
  <html>
  <head>
    <title>মালতী</title>
     <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
      <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.1/css/all.min.css">
      <link rel="stylesheet" href="/css/bootstrap-grid.min.css">
      <link rel="stylesheet" href="explr.css">
      <link rel="preconnect" href="https://fonts.gstatic.com">
        <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.1/css/all.min.css">
      <link href="https://fonts.googleapis.com/css2?family=Big+Shoulders+Stencil+Text:wght@700&display=swap" rel="stylesheet">
      <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.1.3/css/bootstrap.min.css" integrity="sha384-MCw98/SFnGE8fJT3GXwEOngsV7Zt27NXFoaoApmYm81iuXoPkFOJwJ8ERdknLPMO" crossorigin="anonymous">
      <link rel="preconnect" href="https://fonts.gstatic.com">
<link href="https://fonts.googleapis.com/css2?family=Abril+Fatface&display=swap" rel="stylesheet">
<style>
  .nav-item{
    color: #641016;
    font-weight: bold;
font-family: 'Abril Fatface', cursive;
  }
  .nav-item:hover{
   color : yellow; 
   transform:scale(1.1);
  }
p{
  color: #ffffff;
}
h3{
 
  font-family: 'Abril Fatface', cursive;

}
table,tr,th,td
            {
                border: 2px solid #641016;
            }
            table td.wideRow, table th.wideRow {
  width: 500px;
}
th{

  color:yellow;
}
</style>
  </head>
  <body style="background-color:black" >
  <div class="container">
    <header class="mx-0 " >
      <nav class="navbar navbar-expand-md navbar-dark fixed-top">
    <a class="navbar-brand" href="file:///C:/Users/Ruhina/Desktop/B4%20WeB/projecting.html">
  <img src="6bfd6d9ed685fc2b0af4bed3f790c0ae.jpg" style="width:100px" class="rounded-circle"alt="Maloti">
      </a>
      <div class="collapse navbar-collapse" id="navbarNav">

    <ul class="navbar-nav ">

      <li class="nav-item active font-weight-bolder">
       <button class="btn btn-lg bg-warning mr-3 " style="font-weight: bolder"> <a class="nav-link" style="color: #641016 ;font-weight: bolder;" href="#বাঙালি">AUTHOR LIST<span class="sr-only">(current)</span></a></button>
      </li>
     
      <li class="nav-item">
        <button class="btn btn-lg bg-warning " ><a class="nav-link" href="http://localhost/project/upload.php" style="color: #641016">BLOG SECTION</a></button>
      </li>

     
    </ul>
  </div>
  <img src="tagore.jpg" class="rounded-circle " style="height: 70px" >
</nav>
</header>

<main>
  <br> <br> <br> <br><br><br><br>
   <h1 style=" color: #641016; font-family: 'Big Shoulders Stencil Text', cursive;" class="text-center">Rabindranath Tagore</h1>
  <nav>
  <div class="nav nav-tabs" id="nav-tab" role="tablist">
    <a class="nav-item nav-link active " id="nav-profile-tab" data-toggle="tab" href="#nav-profile" role="tab" aria-controls="nav-profile" aria-selected="true">Profile</a>
    <a class="nav-item nav-link" id="nav-novel-tab" data-toggle="tab" href="#nav-novel" role="tab" aria-controls="nav-novel" aria-selected="false">Novel</a>
    <a class="nav-item nav-link" id="nav-poetry-tab" data-toggle="tab" href="#nav-poetry" role="tab" aria-controls="nav-poetry" aria-selected="false">Poetry</a>
    <a class="nav-item nav-link" id="nav-sstory-tab" data-toggle="tab" href="#nav-sstory" role="tab" aria-controls="nav-sstory" aria-selected="false">Drama</a>
  </div>
</nav>
<div class="tab-content" id="nav-tabContent">
  <div class="tab-pane fade show active " id="nav-profile" role="tabpanel" aria-labelledby="nav-profile-tab"><img class="mr-4 mb-4" style="float: left ;width:350px;height: 400px" src="tagoreprofile.jpg"><br>
   
<p class="mx-auto" style="color:white">
 <br> 

Date of Birth: May 7, 1861
<br>
Place of Birth: Calcutta, British India
<br><br>
Father: Debendranath Tagore
<br>
Mother: Sarada Devi
<br><br>
Award: Nobel Prize in Literature (1913)
<br><br>
Title : Kabiguru
<br><br>
Spouse: Mrinalini Devi
<br><br>
Date of Death: August 7, 1941
<br>
Place of Death: Calcutta, British India
<br>
<br>
<br>
<h3 style="color:#641016">Birth, Early Life, Family and Education:</h3>
<p>
Rabindranath Tagore was born as Robindronath Thakur on May 7, 1861, to Debendranath Tagore and Sarada Devi in Calcutta, Bengal Presidency, British India(present-day Kolkata, West Bengal, India). Tagore's mother Sarada Devi died when he was a child and his father  Debendranath Tagore travelled a lot. Therefore, Tagore was raised by servants. Dwijendranath, Rabindranath Tagore's oldest brother, was a philosopher and poet. Tagore's other brother Satyendranath was the first Indian to be appointed in the Indian Civil Service. His brother,  Jyotirindranath, was a musician, composer, and playwright while sister Swarnakumari was a novelist. 
<br><br>

Rabindranath's brother Hemendranath taught him anatomy, geography and history, literature, mathematics, Sanskrit, and English. At the age of 11 after his Janeu, Tagore toured India with his father. Rabindranath Tagore visited his father's Santiniketan estate and stayed in Amritsar for a month before reaching the Himalayan hill station of Dalhousie where Tagore read biographies, studied history, astronomy, modern science, Sanskrit, and examined the classical poetry of 'Kalidasa'. Tagore was highly influenced with the Gurbani and Nanak Bani which were sung at Golden Temple, Amritsar. In 1882, Tagore made his debut with a short story in Bengali 'Bhikarini'. 
<br><br>
In 1878, Rabindra Nath Tagore enrolled himself at a public school in England because his father wanted him to be a barrister. Tagore read law at University College, London, but opted out again to study independently. He read  Shakespeare's plays Coriolanus, and Antony and Cleopatra and the Religio Medici of Thomas Browne which highly impressed him. 
<br><br>
In 1880, Tagore returned to Bengal without any degree and started publishing poems, stories and novels. Although he didn't receive any recognition at the national level but became famous in Bengal. 
</p>
<h3 style="color:#641016">Personal Life : </h3>
<p>In 1883, Tagore married Mrinalini Devi (who was 10 years old at that time) and the couple had 5 children (2 died in early childhood). In 1890, Tagore started manging his ancestral estates in Shelaidaha (present-day in Bangladesh) and his wife joined him in 1898 with their children</p>
<h3 style="color:#641016">Notable works : </h3>
<p> In 1890, Tagore released one of his best poems 'Manasi'. During 1891-1895, Tagore wrote more than half of the stories of 'Galpaguchchha'. 
<br><br>
In 1901, Rabindranath Tagore moved to Santiniketan where he found 'The Mandir' which was an experimental school having trees, gardens and library. Tagore's wife and 2 children died at Santiniketan and Tagore lost his father in 1905. Tagore received monthly payments from Maharaja of Tripura (as part of his inheritance), sales of his family's jewellery, his seaside bungalow in Puri, and a derisory 2,000 rupees in book royalties. In 1901, Tagore published 'Naivedya' and in 1906, he published 'Kheya'. 
<br><br>
In 1913, Tagore won  Nobel Prize in Literature. King George V awarded Tagore with  1915 Birthday Honours which the later abandoned after Jallianwala Bagh massacre in 1919 and wrote a letter for the same to  Lord Chelmsford, the then British Viceroy of India. 
<br><br>
In 1919, Rabindranath Tagore was invited by Syed Abdul Majid (also known as Kaptan Miah) to visit Sylhet, where over 5000 people gathered. Syed Abdul Majid was the president and chairman of Anjuman-e-Islamia. 
<br><br>
In 1921, Tagore along with Leonard Elmhirst (agricultural economist), set up the 'Institute for Rural Reconstruction' which was later renamed 'Shriniketan' in Surul. Tagore started receiving donations from Indian and around the world to free the Indian villages from the shackles of helplessness and ignorance by strengthening their knowledge. In 1930, Tagore lectured against 'abnormal caste consciousness' and 'untouchability'. He campaigned against these issues, penned several poems and finally managed to open doors of Guruvayoor Temple to Dalits. 
<br><br>
In May 1932, Rabindranath Tagore visited Bedouin encampment where the tribal chief stats that as per Prophet Muhammad true Muslim is one by whose words and deeds not the least of his brother-men may ever come to any harm. In 1934, Bihar was hit by an earthquake and killed thousands of people which Gandhi hailed as Karma. Tagore was of a different view and rebuked Gandhi for his implications. Tagore mourned the poverty of Calcutta and the decline of Benga which he penned in a hundred-line poem. In 1932, Tagore published his prose-poem works-- Punashcha, Shes Saptak in 1935 and Patraout in 1936. In 1914, Tagore published his prose-songs and dance drama works in Chitra, Shyama in 1939 and Chandalika in 1938. Tagore published three novels-- Dui Bon in 1933, Malancha and Char Adhyay in 1934. Rabindranath Tagore after inclining towards science wrote stories-- Se in 1937, Tin Sangi in 1940 and Galpasalpa in 1941. </p>
<h3 style="color:#641016">Death :</h3>
<p>In late 1937, Rabindranath Tagore began losing consciousness and remained in a coma for a long period. In 1940, Tagore again went in a coma and never recovered. After years of chronic pain and long term illness, Tagore died on August 7, 1941, at the age of 80 years. Rabindranath Tagore took his last breath in the mansion he was brought up. </p>
  </div>
  <div class="tab-pane fade" id="nav-novel" role="tabpanel" aria-labelledby="nav-novel-tab">

<?php

if(isset($_POST['search']))
{
    $valueToSearch = $_POST['valueToSearch'];
    // search in all table columns
    // using concat mysql function
    $query = "SELECT * FROM `rabindra` WHERE CONCAT( `name`, `writer`, `category`,`description`,`link`) LIKE '%".$valueToSearch."%'";
    $search_result = filterTable($query);
    
}
 else {
    $query = "SELECT * FROM `rabindra`";
    $search_result = filterTable($query);
}

// function to connect and execute the query
function filterTable($query)
{
    $connect = mysqli_connect("localhost", "root", "", "blog");
    $filter_Result = mysqli_query($connect, $query);
    return $filter_Result;
}

?>

 <form action="try.php" method="post"> 
            <input type="text" name="valueToSearch" placeholder="Value To Search"><br><br>
            <input type="submit" name="search" value="Filter"><br><br>
             <table style="border: 2px solid #641016;" class="text-white">
                <tr class="my-4">
                   
                    <th>Name</th>
                    <th>Writer</th>
                    <th>Category</th>
                    <th class="corner wideRow">Description</th>
                    <th>Link</th>
                </tr>

      <!-- populate table from mysql database -->
                <?php while($row = mysqli_fetch_array($search_result)):?>
                <tr>
                    
                    <td style="color: Yellow"><?php echo $row['name'];?></td>
                    <td><?php echo $row['writer'];?></td>
                    <td><?php echo $row['category'];?></td>
                     <td><?php echo $row['description'];?></td>
                      <td><?php echo $row['link'];?></td>
                </tr>
                <?php endwhile;?>
            </table>
        </form>
  </div>
  <div class="tab-pane fade" id="nav-poetry" role="tabpanel" aria-labelledby="nav-poetry-tab">...</div>
    <div class="tab-pane fade" id="nav-sstory" role="tabpanel" aria-labelledby="nav-sstory-tab">...</div>
</div>
   <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/4.5.0/js/bootstrap.bundle.min.js"></script>
  
</main>
</div>
</body>