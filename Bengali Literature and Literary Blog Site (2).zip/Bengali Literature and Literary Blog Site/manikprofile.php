
<!DOCTYPE html>
  <html>
  <head>
    <title>Manik Bandopaddhyay</title>
     <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
      <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.1/css/all.min.css">
      <link rel="stylesheet" href="/css/bootstrap-grid.min.css">
      <link rel="stylesheet" href="explr.css">

          <link rel="stylesheet" href="table.css">
      <link rel="preconnect" href="https://fonts.gstatic.com">
        <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.1/css/all.min.css">
      <link href="https://fonts.googleapis.com/css2?family=Big+Shoulders+Stencil+Text:wght@700&display=swap" rel="stylesheet">
      <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.1.3/css/bootstrap.min.css" integrity="sha384-MCw98/SFnGE8fJT3GXwEOngsV7Zt27NXFoaoApmYm81iuXoPkFOJwJ8ERdknLPMO" crossorigin="anonymous">
      <link rel="preconnect" href="https://fonts.gstatic.com">
<link href="https://fonts.googleapis.com/css2?family=Abril+Fatface&display=swap" rel="stylesheet">
<style>
  .nav-item{
    color: #641016;
    font-weight: bold;
font-family: 'Abril Fatface', cursive;
  }
  .nav-item:hover{
   color : yellow; 
   transform:scale(1.1);
  }
p{
  color: #ffffff;
}
h3{
 
  font-family: 'Abril Fatface', cursive;

}
table,th,td,tr{
border: 1px solid black;
}
            table td.wideRow, table th.wideRow {
  width: 500px;
}
th{

  color:yellow;
}
</style>
  </head>
  <body style="background-color:black" >
  <div class="container">
    <header class="mx-0 " >
      <nav class="navbar navbar-expand-md navbar-dark fixed-top">
    <a class="navbar-brand" href="http://localhost/project/projecting.php">
  <img src="6bfd6d9ed685fc2b0af4bed3f790c0ae.jpg" style="width:100px" class="rounded-circle"alt="Maloti">
      </a>
      <div class="collapse navbar-collapse" id="navbarNav">

    <ul class="navbar-nav ">

       <li class="nav-item active font-weight-bolder">
       <button class="btn btn-lg  mr-3 " style="font-weight: bolder ;background-color: yellow"> <a class="nav-link" style="color: yellow;background-color: #641016" href="http://localhost/project/explore.php">AUTHOR LIST<span class="sr-only">(current)</span></a></button>
     </li>
     <li class="nav-item ">
       <button class="btn btn-lg bg-warning mr-3 " > <a class="nav-link" style="color: #641016" href="http://localhost/project/Booklist.php">BOOK LIST</a></button>
      </li>
      <li class="nav-item">
        <button class="btn btn-lg bg-warning " ><a class="nav-link" href="http://localhost/project/upload.php" style="color: #641016">BLOG SECTION</a></button>
      </li>

     
    </ul>
  </div>
  <img src="manik.jpg" class="rounded-circle " style="height: 70px" >
</nav>
</header>

<main>
  <br> <br> <br> <br><br><br><br>
   <h1 style=" color: #641016; font-family: 'Big Shoulders Stencil Text', cursive;" class="text-center">Manik Bandopaddhyay</h1>
  <nav>
  <div class="nav nav-tabs" id="nav-tab" role="tablist">
    <a class="nav-item nav-link active " id="nav-profile-tab" data-toggle="tab" href="#nav-profile" role="tab" aria-controls="nav-profile" aria-selected="true">Profile</a>
    <a class="nav-item nav-link" id="nav-novel-tab" data-toggle="tab" href="#nav-novel" role="tab" aria-controls="nav-novel" aria-selected="false">Novel</a>

    <a class="nav-item nav-link" id="nav-sstory-tab" data-toggle="tab" href="#nav-sstory" role="tab" aria-controls="nav-sstory" aria-selected="false">Story Book</a>
  </div>
</nav>
<div class="tab-content" id="nav-tabContent">
  <div class="tab-pane fade show active " id="nav-profile" role="tabpanel" aria-labelledby="nav-profile-tab"><img class="mr-4 mb-4" style="float: left ;width:350px;height: 400px" src="manik1.jpg"><br>
   
<p class="mx-auto" style="color:white">
 <br> <br>

Date of Birth: May 19, 1908
<br>
Place of Birth: Dumka,Santal Pargona,Bihar
<br><br>
Father: Harihar Bandopadhyay
<br>
Mother: Niroda Devi
<br><br>
Works: 42 Novels & 250 Short Stories<br><br>
Spouse: Kamala Devi
<br><br>
Date of Death: December 3, 1956
<br>
Place of Death: Calcutta, India
<br>
<br>
<br><br><br><br>
<h3 style="color:#641016">Birth, Early Life, Family and Education:</h3>
<p>
Born in a small town called Dumka, in Santal Paragona district of Bihar, Manik Bandopadhyay was the fifth of the fourteen children born to Harihar Bandopadhyay and Niroda Devi. He was named Prabodh Kumar Bandopadhyay at birth which he later gave up to write under the pen name of 'Manik'. Being born to a father who was a government official, young Manik had the chance to experience different lifestyles and meet different people of Bengal. These experiences were later reflected in his novels and short stories.
<br><br> On 28th May 1924, at a tender age of sixteen, he lost his mother and this unfortunate incident left a deep and permanent mark in the mind of Manik Bandopadhyay. It ultimately led him to become a recluse and he cut off ties with his immediate family. In 1926, Manik Bandopadhyay passed the entrance examination from Midnapore Zilla School with a first division and a distinction in optional and compulsory Mathematics. He then joined Welleslyvan Mission College at Bankura and came in contact with a professor named Jackson. This professor highly influenced Manik Bandhopadhyay to read the Bible and cultivate a broader outlook towards religion in general.<br><br>  In 1928, Bandopadhyay cleared the Indian School Certficate exam or the 12th board's exam with first division. It was not difficult for this illustrious student to gain admission in the prestigious Presidency College, Calcutta for a Bachelor of Science degree in Mathematics. This degree, however, he couldn't complete on account of lack of funds. With degrees in the field of Mathematics, it was poverty that propelled Manik Bandopadhyay to write. He joined the Mymensingh Teacher's Training School as its headmaster. He married Kamala Devi in Dhaka, Bangladesh and had two sons and two daughters.

</p>
<h3 style="color:#641016">Career : </h3>
<p>In 1938 Bandopadhyay started his career as the Headmaster of Mymensingh Teachers Training School. But, throughout his life, writing was the only source of income for Manik Bandopadhyay and, hence, he languished perpetual poverty. However, for a short while he tried to enhance his earning through involvement with one or two literary magazines. He worked as editor of Nabarun for a few months in 1934. During 1937–38, he worked as assistant editor of literary magazine Bangasree. He established a printing and publishing house in 1939 which turned out to be a short-lived endeavour. Also, he worked as publicity assistant for the government of India in 1943.</p>
<br><br>

<h3 style="color:#641016">Literary Life:</h3>
<p>Once while he was with his friends in their college canteen, one of them asked him if he could publish a story in the magazine Bichitra. The would-be novelist replied that his first story would be good enough for the purpose. At that time, Bichitra was a leading periodical which carried stories only by eminent authors. Manik walked into the office of the periodical and dropped the story "Atashimami (Aunt Atashi)" in their letter box. At the end of the story he signed off as Manik Bandhopadhay. After four months, publication of the story (in 1928) created sensation in the literary circles of Bengal and, from then on, the nom de plume stuck.

His stories and novels were published in literary magazines of the then Bengal. They included Bichitra, Bangasree, Purbasha, AnandaBazaar Patrika, Jugantor, Satyajug, Probashi, Desh, Chaturanga, NoroNari, Notun Jiban, Bosumati, Golp-Bharati, Mouchak, Pathshala, Rang-Mashal, NoboShakti, Swadhinata, Agami, Kalantar, Parichaya, Notun Sahitya, Diganta, Sanskriti, Mukhopotro, Provati, Ononnya, Ultorath, Elomelo, Bharatbarsha, Modhyabitta, Sharodi, Sonar Bangla, Agami, Ononya, Krishak, Purnima, Rupantar and Swaraj.

Manik published as many as 57 volumes. He also wrote poetry, but not much is heard about his poems.</p>
<h3 style="color:#641016">Writing Style :</h3>
<p>
  Manik Bandopadhyay's writing was inspired by both Marxian philosophy and Freudian philosophy - which are quite contrasting in nature. His writing stands in stark contrast to that of other contemporary luminaries like Bibhutibhushan Bandopadhyay who portrayed life in rural Bengal in a gentle, lyrical light. Although he had some common grounds with Tarashankar Bandopadhyay, he distinguished himself with profound and rational analysis of the lives of ordinary people. Manik's writing dealt with the pettiness and wretchedness of existence in the context of rural Bengal. His primary concern was the dark alleyways of the human mind, even among the supposedly simple village folk, and not the serene beauty of nature that was always in the background in his novels. In Putulnacher Itikatha he took on rather savagely the hypocrisy in villages: An elderly couple are canonised as saints after committing morphine-induced suicide; the daughter of one of the village elders gets married off to a wealthy businessman in Kolkata who treats her as a concubine ... she gets hooked to alcohol and returns home a shadow of her former self. However, the people around her keep pretending that nothing untoward has happened. Numerous other examples abound.
  <br><br>
  Shortly after making his debut in the world of fiction in 1935 through a short story titled Atashi Mami("অতসী মামী"), Manik Bandopadhay embarked upon writing novels. Publication of Diba-Ratrir Kabya in 1935 and Padma Nadir Majhi and Putul Nacher Itikotha in 1936 established him as the most notable novelist Bengali literature since Bankimchandra, Rabindranath and Saratchandra. He distinguished himself with focus on the life of ordinary rural and urban people, with colloquial language and with a neat narrative. He was a great storyteller who perfected his fiction with insight into human mind. In the earlier works he took a Freudian approach. In the later life, he showed influence of Marxist theory. His treatment of human sexuality in Chatushkone is path-breaking.
  <br><br>
  <h3 style="color:#641016">Political View :</h3>
  <p>Manik carefully read Marx and Engels and became a Marxist. He became an active politician of Marxism by joining the Communist Party of India in 1944.However, it is said that he regretted this decision and thought of the Communist Party as an increasingly hollow and tyrannical organization.</p>
</p>
<h3 style="color:#641016">Death :</h3>
  <p>Since early life he had struggled with poverty and epilepsy. The signs of epilepsy first surfaced when he was engaged in writing Padma Nadir Majhi and Putul Nacher Itikatha. Continued and unabated ailment, problems and crises devastated his mental disposition. Eventually he resorted to alcohol for respite, adding to his misery. On 3 December 1956, he collapsed and went into a coma. He was admitted to the Nilratan Government Hospital on 2 December where he died the next day. He was 48. His funeral took place at Nimtala crematorium in North Calcutta. A huge crowd attended the memorial meeting for Manik Bandopadhyay held on 7 December 1956.At that time he lived in Baranagar, now in North 24 Parganas. The rental residence was at Gopallal Tagore Road.</p>
  <h3 style="color:#641016">Legacy :</h3>
<p>
'Putul Nacher Itikotha' (The Tale of Puppet Dance) which was written by Manik Bandopadhyay in 1936 and was published in 'Bharatbarsha'. A movie was also produced based on this novel in 1949. Almost four decades after Manik's death, West Bengal Government published a book on his lifetime contribution to Bengali literature.</p>
</p>
  </div>
  <div class="tab-pane fade" id="nav-novel" role="tabpanel" aria-labelledby="nav-novel-tab">

<?php

if(isset($_POST['search']))
{
    $valueToSearch = $_POST['valueToSearch'];
    // search in all table columns
    // using concat mysql function
    $query = "SELECT * FROM `maniknovel` WHERE CONCAT( `name`, `writer`, `category`,`description`,`link`) LIKE '%".$valueToSearch."%'";
    $search_result = filterTable($query);
    
}
 else {
    $query = "SELECT * FROM `maniknovel`";
    $search_result = filterTable($query);
}

// function to connect and execute the query
function filterTable($query)
{
    $connect = mysqli_connect("localhost", "root", "", "blog");
    $filter_Result = mysqli_query($connect, $query);
    return $filter_Result;
}

?>

 <form action="manikprofile.php" method="post"> 
            <br><br>
             <table style="border: 2px solid #641016;" class="text-white">
                <tr class="my-4">
                   
                    <th>Name</th>
                    <th>Writer</th>
                    <th>Category</th>
                    <th class="corner wideRow">Description</th>
                    <th>Link</th>
                </tr>

      <!-- populate table from mysql database -->
                <?php while($row = mysqli_fetch_array($search_result)):?>
                <tr>
                    
                    <td style="font-weight: bolder"><?php echo $row['name'];?></td>
                    <td><?php echo $row['writer'];?></td>
                    <td><?php echo $row['category'];?></td>
                     <td><?php echo $row['description'];?></td>
                      <td><?php echo $row['link'];?></td>
                </tr>
                <?php endwhile;?>
            </table>
        </form>
  </div>


 

    <div class="tab-pane fade" id="nav-sstory" role="tabpanel" aria-labelledby="nav-sstory-tab">

<?php

if(isset($_POST['search']))
{
    $valueToSearch = $_POST['valueToSearch'];
    // search in all table columns
    // using concat mysql function
    $query = "SELECT * FROM `maniksstory` WHERE CONCAT( `name`, `writer`, `category`,`description`,`link`) LIKE '%".$valueToSearch."%'";
    $search_result = filterTable($query);
    
}
 else {
    $query = "SELECT * FROM `maniksstory`";
    $search_result = filterTable($query);
}

// function to connect and execute the query
function filterTable3($query)
{
    $connect = mysqli_connect("localhost", "root", "", "blog");
    $filter_Result = mysqli_query($connect, $query);
    return $filter_Result;
}

?>

 <form action="maniikprofile.php" method="post"> 
          <br><br>
             <table style="border: 2px solid #641016;" class="text-white">
                <tr class="my-4">
                   
                    <th>Name</th>
                    <th>Writer</th>
                    <th>Category</th>
                    <th class="corner wideRow">Description</th>
                    <th>Link</th>
                </tr>

      <!-- populate table from mysql database -->
                <?php while($row = mysqli_fetch_array($search_result)):?>
                <tr>
                    
                    <td style="font-weight:bolder"><?php echo $row['name'];?></td>
                    <td><?php echo $row['writer'];?></td>
                    <td><?php echo $row['category'];?></td>
                     <td><?php echo $row['description'];?></td>
                      <td><?php echo $row['link'];?></td>
                </tr>
                <?php endwhile;?>
            </table>
        </form>

    </div>
</div>
   <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/4.5.0/js/bootstrap.bundle.min.js"></script>
  
</main>
</div>
</body>