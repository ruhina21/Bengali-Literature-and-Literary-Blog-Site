
<!DOCTYPE html>
<html lang="en" dir="ltr">
  <head>
    <meta charset="utf-8">
    <title>projectt</title>
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.1/css/all.min.css">
    <link rel="stylesheet" href="/css/bootstrap-grid.min.css">
    <link rel="stylesheet" href="style.css">
    <link rel="preconnect" href="https://fonts.gstatic.com">
      <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.1/css/all.min.css">
    <link href="https://fonts.googleapis.com/css2?family=Big+Shoulders+Stencil+Text:wght@700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.1.3/css/bootstrap.min.css" integrity="sha384-MCw98/SFnGE8fJT3GXwEOngsV7Zt27NXFoaoApmYm81iuXoPkFOJwJ8ERdknLPMO" crossorigin="anonymous">
 <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/rateYo/2.3.2/jquery.rateyo.min.css">
       <style>
       .features-col:hover{
      transform:scale(1.1);
      box-shadow:2px 6px 5px #970900;
       }
.center {
  margin-left: auto;
  margin-right: auto;
}
table,tr,th,td
            {
                border: 2px solid #641016;

            }
            table td.wideRow, table th.wideRow {
  width: 500px;
}
       </style>


  </head>
  <body style="background-color:black">
       <?php session_start(); ?>
<div class="container">
  <header class="mx-0 " >
    <nav class="navbar  navbar-expand-md navbar-dark ">
  <a class="navbar-brand" href="http://localhost/project/projecting.php">
<img src="6bfd6d9ed685fc2b0af4bed3f790c0ae.jpg" style="width:100px" class="rounded-circle"alt="Maloti">
  </a>
  <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
    <span class="navbar-toggler-icon"></span>
  </button>
  <div class="collapse navbar-collapse" id="navbarNav">

    <ul class="navbar-nav ">

      <li class="nav-item active font-weight-bolder">
        <a class="nav-link" href="#">HOME <span class="sr-only">(current)</span></a>
      </li>
      <li class="nav-item">
        <a class="nav-link =" href="#features">FEATURES</a>
      </li>
        <li class="nav-item">
        <a class="nav-link" href="#rateus">RATE US</a>
      </li>
      <li class="nav-item">
        <a class="nav-link" href="#aboutus">ABOUT US</a>
      </li>

    
    </ul>
  </div>
     <a class="nav-link text-white" href="logout.php">LOG OUT</a>
      <a class="nav-link text-white" href="blog.php"><?php

    echo $_SESSION['user_name'];
    ?></a>
   
     </nav>
    <?php
    echo "<img src=".$filename." height=200 width=300 />";
    echo "You are registered as ".$_SESSION['user_name'];
    ?>
 
<section id="banner">
  <div class="banner-container" >
    <div class="banner-contents ">
      <br>
      <br>
      <br>
      <br>
      <br>
      <br><br><br> <br><br><br> <br><br><br>
<h1 class="pt-4 text-center">“A reader lives a thousand years before he dies.<br> The man who never reads lives only one.”</h1><br><br>
<div class="text-center mr-40%">
<button class="btn btn-lg  text-white mr-3" style="float:center;" ><a href="http://localhost/project/explore.php" style="color: white "> EXPLORE </a></button>
</div>
    </div>
  </div>
</section>
  </header>
  <main>
    <br><br>
 <br><br><br>
    <section id="features" class="text-center justified-content-center" >
      <div class="section-title">
        <h2 class="text-center">FEATURES</h2>
        </div>
            <hr class="hr-style" style="border-color:white">
      <div class="row  "  >
        <div class="col-lg-4 d-lg-flex"style="border:1px solid #4a3b00 padding:15px">
      <div class="features-col " style="background-color:rgb(52, 24, 24,0.3)   ">
<br>
        <i class="fas fa-book-reader"></i>
        <br>
        <br>
            <h3>tdfhfhb</h3>
            <p class="small">Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.</p>
      </div>
      </div>
      <div class="col-lg-4 d-lg-flex " style="border:1px solid #4a3b00 padding:15px">
    <div class="features-col " style="background-color:rgb(52, 24, 24,0.3)">
<br>
      <i class="fas fa-book-reader"></i>
      <br>
      <br>
          <h3>tdfhfhb</h3>
          <p class="small ">Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.</p>
    </div>
    </div>
    <div class="col-lg-4 d-lg-flex" style="border:1px solid #4a3b00 padding:15px margin:20px transition:.4s">
    <div class="features-col " style="background-color:rgb(52, 24, 24,0.3)  ">
<br>
    <i class="fas fa-book-reader"></i>
    <br>
    <br>
        <h3>tdfhfhb</h3>
        <p class="small">Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.</p>
  </div>
  </div>
      </div>
<br>
<br>
<br>
    </section>

  <section id="rateus">
    <div class="section-title">
      <h2 class="text-center">Rate Us</h2>
      </div>
      <hr class="hr-style" style="border-color:white">
      

<form action="projecting.php" method="post" style="background-color: rgb(52, 24, 24,0.3)   ">

    <div>
        <h3>Rate And Let Us Know Your Feedback !!</h3>
    </div>

    <div>
         
    </div>
<label>name</label>
        <input type="hidden" name="name" value="<?php echo $_SESSION['user_name']; ?>">
         <div class="rateyo" id= "rating"
         data-rateyo-rating="4"
         data-rateyo-num-stars="5"
         data-rateyo-score="3">
         </div>

    <span class='result'>0</span>
    <input type="hidden" name="rating">

    <br><br>
        

    <label>Comment</label>
<input type="text" name="comment" style="width: 500px ;height: 50px">

    <div><input type="submit" name="add" > </div>

</form>

<?php

if(isset($_POST['search']))
{
    $valueToSearch = $_POST['valueToSearch'];
    // search in all table columns
    // using concat mysql function
    $query = "SELECT * FROM `ratee` WHERE ( `name`, `rating`, `comment`,'date') LIKE '%".$valueToSearch."%'";
    $search_result = filterTable2($query);
    
}
 else {
    $query = "SELECT * FROM `ratee`";
    $search_result = filterTable2($query);
}

// function to connect and execute the query
function filterTable2($query)
{
    $connect = mysqli_connect("localhost", "root", "", "billdb");
    $filter_Result = mysqli_query($connect, $query);
    return $filter_Result;
}
    $conn= mysqli_connect("localhost", "root", "", "billdb");
?>
<?php
$localhost = "localhost"; #localhost
$dbusername = "root"; #username of phpmyadmin
$dbpassword = "";  #password of phpmyadmin
$dbname = "billdb";  #database name
 
#connection string

$conn2 = mysqli_connect($localhost,$dbusername,$dbpassword,$dbname);

$query=mysqli_query($conn, "select * from ratee");
$rowcount=mysqli_num_rows($query);
?>
<br> <br><br>
<div class="container" >
<div class="card-body text-center"  style="background-color: black">
                <h4 class="card-title" >Latest Reviews</h4>
            </div>
<?php
for($i=1;$i<=$rowcount;$i++)
{
  $row=mysqli_fetch_array($query);

?>
        <?php
$commenter=$row["name"];
$query5=mysqli_query($conn2,"SELECT * from regform WHERE username='$commenter'");


?>
<?php
for($i=1;$i<=$rowcount;$i++)
{
  $sfl=mysqli_fetch_array($query5);
}
?>
<div class="row d-flex justify-content-center mt-100 mb-100">
    <div class="col-lg-1">
       <div class="p-2 my-auto"><img style="width: 50px;" class="rounded-circle mr-3" src="<?php echo $_SESSION['img_s']; ?>" alt="picture"/>

                    </div>
                        <h6 class="font-medium"><?php echo $row["name"] ;?></h6>
                       <?php echo "Age : ".$sfl['age'] ;?>
                  </div>
                  <div class="col-lg-10 my-auto">
        <div class="card">
            
            <div class="comment-widgets  my-auto" style="background-color:black">
                <!-- Comment Row -->

                <div class="d-flex flex-row comment-row m-t-0"  style="background-color:rgb(52, 24, 24,0.3) ;border-color : black">
                  
                    <div class="comment-text w-100">
                      <div class="my-auto ">
                    
                        <p style="color: yellow">Rating : <?php echo $row["rating"]; ?></p>
                          <span class="m-b-15 d-block"><?php echo $row["comment"]; ?> </span><br>
                        </div>
                        <div class="comment-footer"> <span class="text-muted float-right"><?php echo $row["date"]; ?></span> 
                        </div>
                    </div>
                </div> <!-- Comment Row -->
               </div> 
        </div>
    </div>
  </div>


<?php 
}

?>

          </div>
</div>
  </section>

<br><br><br>
  <section id="aboutus">
    <div class="container">
    <div class="section-title">
      <h2 class="text-center">ABOUT US</h2>
      </div>
      <hr class="hr-style" style="border-color:white">
      <div class="text-center">
      <img src="me.jpg" alt="i" class="rounded-circle my-auto" >
      </div>
<p class="text-center">Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.</p>
</div>
  </section>

  </div>
  </main>
  <footer>

  </footer>
</div>



        <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js" integrity="sha384-DfXdz2htPH0lsSSs5nCTpuj/zy4C+OGpamoFVy38MVBnE+IbbVYUew+OrCXaRkfj" crossorigin="anonymous"></script>
            <script src="https://cdn.jsdelivr.net/npm/bootstrap@4.5.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-ho+j7jyWK8fNQe+A12Hb8AhRq26LrZ/JpcUGGOn+Y7RsweNrtN/tE3MoK7ZeZDyx" crossorigin="anonymous"></script>
            <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js" integrity="sha384-DfXdz2htPH0lsSSs5nCTpuj/zy4C+OGpamoFVy38MVBnE+IbbVYUew+OrCXaRkfj" crossorigin="anonymous"></script>
            <script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.1/dist/umd/popper.min.js" integrity="sha384-9/reFTGAW83EW2RDu2S0VKaIzap3H66lZH81PoYlFhbGU+6BZp6G7niu735Sk7lN" crossorigin="anonymous"></script>
            <script src="https://cdn.jsdelivr.net/npm/bootstrap@4.5.3/dist/js/bootstrap.min.js" integrity="sha384-w1Q4orYjBQndcko6MimVbzY0tgp4pWB4lZ7lr30WKz0vr/aWKhXdBNmNb5D92v7s" crossorigin="anonymous"></script>

<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/rateYo/2.3.2/jquery.rateyo.min.js"></script>

<script>


    $(function () {
        $(".rateyo").rateYo().on("rateyo.change", function (e, data) {
            var rating = data.rating;
            $(this).parent().find('.score').text('score :'+ $(this).attr('data-rateyo-score'));
            $(this).parent().find('.result').text('rating :'+ rating);
            $(this).parent().find('input[name=rating]').val(rating); //add rating value to input field
        });
    });

</script>

  </body>
</html>

<?php
require 'db_connection.php';
if ($_SERVER["REQUEST_METHOD"] == "POST")
{
$name=$_POST['name'];
    $rating = $_POST['rating'];
  $comment = $_POST["comment"];
    $sql = "INSERT INTO ratee (name,rating,comment) VALUES ('$name','$rating','$comment')";
    if (mysqli_query($conn, $sql))
    {
        echo "  ";
    }
    else
    {
        echo "Error: " . $sql . "<br>" . mysqli_error($conn);
    }
    mysqli_close($conn);
}
