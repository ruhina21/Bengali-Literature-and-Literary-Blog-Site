<?php

$localhost = "localhost"; #localhost
$dbusername = "root"; #username of phpmyadmin
$dbpassword = "";  #password of phpmyadmin
$dbname = "ruhina";  #database name
 
#connection string

$conn = mysqli_connect($localhost,$dbusername,$dbpassword,$dbname);

$query=mysqli_query($conn,"select * from blobb");
$rowcount=mysqli_num_rows($query);
?>
<table>
<tr>
<th>Name</th>
<th>Author</th>
<th>Blog</th>
<th>Time of Upload</th>

</tr>



for($i=1;$i<=$rowcount;$i++)
{
	$row=mysqli_fetch_array($query);

?>
<tr>
<td><?php echo $row['title'] ;?></td>
<td><?php echo $row['writer']; ?></td>
<td><a href="uploads/<?php echo $row["file"] ;?>"><?php echo $row["file"] ?></a></td>
<td><?php echo $row['date'] ?></td>
</tr>

	
}

</table>