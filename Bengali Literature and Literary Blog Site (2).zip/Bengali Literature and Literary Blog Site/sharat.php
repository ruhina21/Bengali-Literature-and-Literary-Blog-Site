
<!DOCTYPE html>
  <html>
  <head>
    <title>Sharat Chandra Chattopaddhyay</title>
     <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
      <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.1/css/all.min.css">
      <link rel="stylesheet" href="/css/bootstrap-grid.min.css">
      <link rel="stylesheet" href="explr.css">
        <link rel="stylesheet" href="table.css">
      <link rel="preconnect" href="https://fonts.gstatic.com">
        <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.1/css/all.min.css">
      <link href="https://fonts.googleapis.com/css2?family=Big+Shoulders+Stencil+Text:wght@700&display=swap" rel="stylesheet">
      <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.1.3/css/bootstrap.min.css" integrity="sha384-MCw98/SFnGE8fJT3GXwEOngsV7Zt27NXFoaoApmYm81iuXoPkFOJwJ8ERdknLPMO" crossorigin="anonymous">
      <link rel="preconnect" href="https://fonts.gstatic.com">
<link href="https://fonts.googleapis.com/css2?family=Abril+Fatface&display=swap" rel="stylesheet">
<style>
  .nav-item{
    color: #641016;
    font-weight: bold;
font-family: 'Abril Fatface', cursive;
  }
  .nav-item:hover{
   color : yellow; 
   transform:scale(1.1);
  }
p{
  color: #ffffff;
}
i{
  color:grey;
  width: 50%;
}
h3{
 
  font-family: 'Abril Fatface', cursive;

}
table,tr,th,td
            {
                border: 2px solid #641016;

            }
            table td.wideRow, table th.wideRow {
  width: 500px;
}
th{

  color:yellow;
}
</style>
  </head>
  <body style="background-color:black" >
  <div class="container">
    <header class="mx-0 " >
      <nav class="navbar navbar-expand-md navbar-dark fixed-top">
    <a class="navbar-brand" href="http://localhost/project/projecting.php">
  <img src="6bfd6d9ed685fc2b0af4bed3f790c0ae.jpg" style="width:100px" class="rounded-circle"alt="Maloti">
      </a>
      <div class="collapse navbar-collapse" id="navbarNav">

    <ul class="navbar-nav ">

      <li class="nav-item active font-weight-bolder">
       <button class="btn btn-lg  mr-3 " style="font-weight: bolder ;background-color: yellow"> <a class="nav-link" style="color: yellow;background-color: #641016" href="http://localhost/project/explore.php">AUTHOR LIST<span class="sr-only">(current)</span></a></button>
     </li>
     <li class="nav-item ">
       <button class="btn btn-lg bg-warning mr-3 " > <a class="nav-link" style="color: #641016" href="http://localhost/project/Booklist.php">BOOK LIST</a></button>
      </li>
      <li class="nav-item">
        <button class="btn btn-lg bg-warning " ><a class="nav-link" href="http://localhost/project/upload.php" style="color: #641016">BLOG SECTION</a></button>
      </li>

     
    </ul>
  </div>
  <img src="sharat.jpg" class="rounded-circle " style="height: 70px" >
</nav>
</header>

<main>
  <br> <br> <br> <br><br><br><br>
   <h1 style=" color: #641016; font-family: 'Big Shoulders Stencil Text', cursive;" class="text-center">Sharat Chandra Chattopaddhyay</h1>
  <nav>
  <div class="nav nav-tabs" id="nav-tab" role="tablist">
    <a class="nav-item nav-link active " id="nav-profile-tab" data-toggle="tab" href="#nav-profile" role="tab" aria-controls="nav-profile" aria-selected="true">Profile</a>
    <a class="nav-item nav-link" id="nav-novel-tab" data-toggle="tab" href="#nav-novel" role="tab" aria-controls="nav-novel" aria-selected="false">Novels</a>

  </div>
</nav>
<div class="tab-content" id="nav-tabContent">
  <div class="tab-pane fade show active " id="nav-profile" role="tabpanel" aria-labelledby="nav-profile-tab"><img class="mr-4 mb-4" style="float: left ;width:400px;height: 400px" src="sorot.jpg"><br>
   
<p class="mx-auto" style="color:white">
 <br> 

Date of Birth:  September 15, 1876
<br>
Place of Birth: Debanandapur, Bengal Presidency, India
<br><br>
Father: Motilal Chattopadhyay
<br>
Mother:  Bhuvanmohini Chattopadhyay
<br><br>
Nationality: Indian
<br><br>
Spouse: Shanti Devi
<br><br>
Date of Death: January 16, 1938
<br>
Place of Death: Kolkata
<br>
<br>
<br><br><br>
<div class="text-white">
<h3 style="color:#641016">Early life :</h3>
  Sarat Chandra Chattopadhyay was born on September 15, 1876, in Debanandapur, Bengal Presidency, India. His childhood was mostly spent in his grandfather Kedarnath Gangopadhyay’s house, in Bihar, where his father was employed for a while.<br><br>
Motilal Chattopadhyay, his father, held irregular jobs and thus, the family was mired in poverty. He was a writer who spent his days dreaming, idling, and never finishing any of his works. Sarat Chandra’s mother, Bhuvanmohini, took care of the family She passed away in 1895.
Sarat Chandra Chattopadhyay was one of the five children of his parents. After the death of their mother, the family was supported by various other family members during hard times. One of his brothers, Swami Vedananda, later became a disciple at Belur Math.<br><br>
His education began at Pyari Pandit’s pathshala, an informal village school and later he joined Hooghly Branch High School. He was a good student who was also daring and adventurous. Though he enrolled in fine arts, he had to give it up due to the family’s miserable financial state.
He completed his early education while staying at a maternal uncle’s house in Bhagalpur. Once his education was complete, he engaged himself with acting in plays and in sports and games.
<br><br><br>

<h3 style="color:#641016">Literary Career :</h3>
Sarat Chandra Chattopadhyay’s imagination and love for literature were an invaluable gift from his father. He began writing in his early teens. Two stories from this period to have survived are ‘Korel’ and ‘Kashinath’.
His family’s poverty forced him out of pursuing further studies and pushed him to look for work. In 1900, he worked at the Banali Estate in Bihar. He later was an assistant to the Settlement Officer in the Santhal district settlement.
In 1903, at the age of 27, he moved to Burma and worked as a clerk in a government office in Rangoon. He then secured a permanent job in the Accounts Department of Burma Railway. He lived there for nearly 13 years and returned to Baje Shibpur, Howrah, in 1916.
His first short story, ‘Mandir’ (1903) was written at the insistence of his uncle Girindrandra Nath. It won him the Kuntolin Puraskar in 1904 among hundreds of other entries.
He regularly contributed stories to the magazine Jamuna. He did so under three names, his own, Anila Devi (his sister), and Anupama. He would later go on to say that Jamuna was the catalyst in reviving his literary career while he was in Burma.<br><br>
Sarat Chandra Chattopadhyay was a staunch feminist and rejected core Hindu orthodoxy. He did not believe in standard social systems and wrote against superstition and bigotry.<br>
He often wrote about women and their suffering at a time when patriarchy was largely prevalent. This makes his writings quite authentic and revolutionary. ‘Devdas’ (1901, published 1917), ‘Parineeta’ (1914), Biraj Bau (1914), and Palli Samaj (1916) are a reflection of his rejection of social norms.
Between 1921 and 1936, he served as president of Howrah district branch of the Indian National Congress.<br><br>
His writings were also motivated by the ongoing freedom movement in the country. In 1926, he wrote 'Pather Debi'; the story revolved around a revolutionary movement, inspired by Bengal, operating in Burma and in Far East.
<br><br>
His last completed novel was ‘Sesh Prasna’ (1931). It was an intellectual monolog on problems involving love, marriage, individuals, and society.
<br><br><br>
<h3 style="color:#641016">Major Works :</h3>

‘Swami’ was a reflection of his feminism and strong portrayal of female characters. The novel follows Saudamini, an ambitious and bright girl who is conflicted by her emotions towards her lover, Narendra and her husband Ghanshyam.
His most famous work was not critically acclaimed but it stands out as one of his most remembered works. ‘Devdas’ (written 1901, published 1917) was a love story that bowed down to societal norms and depicts the protagonist as a loser. It remains his most popular story, being adapted to the screen no less than eight times in various versions.
‘Parineeta’ (1914) was another of his forays into feminism. It explores themes of caste and religion prevalent at that time. It is set in the early part of the 20th century in Calcutta and is a novel of social protest that tends to break societal rules.
Iti Srikanta’ (1916), a four-part novel, was first published in 1916. It chronicled the life of Srikanta, a wanderlust, and various characters who influence him. It is often believed that Iti Srikanta was based on Chattopadhyay’s own life and travels. The four parts were published in 1916, 1918, 1927, and 1933.
‘Choritrohin’ (1917) [Characterless] is a tale of four women wronged by society. It follows their journey through rejection and ultimately redemption.<br><br><br>

<h3 style="color:#641016">Awards & Achievements :</h3>

Sarat Chandra Chattopadhyay’s first published novel, ‘Mandir’ won the Kuntalin Puraskar in 1904. He had entered the Kuntalin literary competition under the name Surendranath Ganguli.
The University of Calcutta presented him with their Jagattarini medal. He received an honorary doctorate, D.Litt. from the University of Dacca.
<br><br><br>
<h3 style="color:#641016">Personal Life & Legacy :</h3>

Sarat Chandra Chattopadhyay was married twice. His first wife was Shanti Devi, whom he married in 1906 in Burma. They had a son the next year. Shanti Devi and their son were victims of the plague and both passed away in 1908.

The loss of his family shattered him and he turned to books for solace. He read voraciously on sociology, history, philosophy and psychology etc. But he had to slow down in 1909 due to health problems.
Among his many interests were homeopathy, singing, and painting. He also opened a primary school.
In 1910, he married Mokshada, an adolescent widow whom he renamed Hiranmoyee. He taught his young bride to read and write. She outlived him by 23 years.
<br><br><br>
<h3 style="color:#641016">Death :</h3>
He was diagnosed with liver cancer and passed away on January 16, 1938, in Calcutta (now Kolkata).An annual week long fair, Sarat Mela, is held every year in late January, in Howrah, West Bengal. The festival was started in 1972 and showcases his life and works.


</div>
  </div>
  <div class="tab-pane fade" id="nav-novel" role="tabpanel" aria-labelledby="nav-novel-tab">

<?php

if(isset($_POST['search']))
{
    $valueToSearch = $_POST['valueToSearch'];
    // search in all table columns
    // using concat mysql function
    $query = "SELECT * FROM `sharatnovel` WHERE CONCAT( `name`, `writer`, `category`,`description`,`link`) LIKE '%".$valueToSearch."%'";
    $search_result = filterTable($query);
    
}
 else {
    $query = "SELECT * FROM `sharatnovel`";
    $search_result = filterTable($query);
}

// function to connect and execute the query
function filterTable($query)
{
    $connect = mysqli_connect("localhost", "root", "", "blog");
    $filter_Result = mysqli_query($connect, $query);
    return $filter_Result;
}

?>

 <form action="sunilprofile.php" method="post"> 
            <br><br>
             <table style="border: 2px solid #641016;" class="text-white text-center">
                <tr class="mx-4 ml-4 my-4">
                   
                    <th class="mr-4 ml-4 my-4">Name</th>
                    <th class="mr-4 ml-4 my-4">Writer</th>
                    <th class="mr-4 ml-4 my-4">Category</th>
                    <th class="corner wideRow">Description</th>
                    <th class="mr-4 ml-4 my-4">Link</th>
                </tr>

      <!-- populate table from mysql database -->
                <?php while($row = mysqli_fetch_array($search_result)):?>
                <tr class="mr-4 ml-4 my-4">
                    
                    <td style="font-weight: bolder" class="mr-4 ml-4 my-4"><?php echo $row['name'];?></td>
                    <td class="mr-4 ml-4 my-4"><?php echo $row['writer'];?></td>
                    <td class="mr-4 ml-4 my-4"><?php echo $row['category'];?></td>
                     <td class="mr-4 ml-4 my-4"><?php echo $row['description'];?></td>
                      <td class="mr-4 ml-4 my-4"><?php echo $row['link'];?></td>
                </tr>
                <?php endwhile;?>
            </table>
        </form>
  </div>




   <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/4.5.0/js/bootstrap.bundle.min.js"></script>
  
</main>
</div>
</body>