
<!DOCTYPE html>
  <html>
  <head>
    <title>Samaresh Majumdar</title>
     <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
       <link rel="stylesheet" href="table.css">
      <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.1/css/all.min.css">
      <link rel="stylesheet" href="/css/bootstrap-grid.min.css">
      <link rel="stylesheet" href="explr.css">
      <link rel="preconnect" href="https://fonts.gstatic.com">
        <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.1/css/all.min.css">
      <link href="https://fonts.googleapis.com/css2?family=Big+Shoulders+Stencil+Text:wght@700&display=swap" rel="stylesheet">
      <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.1.3/css/bootstrap.min.css" integrity="sha384-MCw98/SFnGE8fJT3GXwEOngsV7Zt27NXFoaoApmYm81iuXoPkFOJwJ8ERdknLPMO" crossorigin="anonymous">
      <link rel="preconnect" href="https://fonts.gstatic.com">
<link href="https://fonts.googleapis.com/css2?family=Abril+Fatface&display=swap" rel="stylesheet">
<style>
  .nav-item{
    color: #641016;
    font-weight: bold;
font-family: 'Abril Fatface', cursive;
  }
  .nav-item:hover{
   color : yellow; 
   transform:scale(1.1);
  }
p{
  color: #ffffff;
}
i{
  color:grey;
  width: 50%;
}
h3{
 
  font-family: 'Abril Fatface', cursive;

}
table,tr,th,td
            {
                border: 2px solid #641016;

            }
            table td.wideRow, table th.wideRow {
  width: 500px;
}
th{

  color:yellow;
}
</style>
  </head>
  <body style="background-color:black" >
  <div class="container">
    <header class="mx-0 " >
      <nav class="navbar navbar-expand-md navbar-dark fixed-top">
    <a class="navbar-brand" href="http://localhost/project/projecting.php">
  <img src="6bfd6d9ed685fc2b0af4bed3f790c0ae.jpg" style="width:100px" class="rounded-circle"alt="Maloti">
      </a>
      <div class="collapse navbar-collapse" id="navbarNav">

    <ul class="navbar-nav ">

      <li class="nav-item active font-weight-bolder">
       <button class="btn btn-lg  mr-3 " style="font-weight: bolder ;background-color: yellow"> <a class="nav-link" style="color: yellow;background-color: #641016" href="http://localhost/project/explore.php">AUTHOR LIST<span class="sr-only">(current)</span></a></button>
     </li>
     <li class="nav-item ">
       <button class="btn btn-lg bg-warning mr-3 " > <a class="nav-link" style="color: #641016" href="http://localhost/project/Booklist.php">BOOK LIST</a></button>
      </li>
      <li class="nav-item">
        <button class="btn btn-lg bg-warning " ><a class="nav-link" href="http://localhost/project/upload.php" style="color: #641016">BLOG SECTION</a></button>
      </li>

     
    </ul>
  </div>
  <img src="samaresh.jpg" class="rounded-circle " style="height: 70px" >
</nav>
</header>

<main>
  <br> <br> <br> <br><br><br><br>
   <h1 style=" color: #641016; font-family: 'Big Shoulders Stencil Text', cursive;" class="text-center">Samaresh Majumdar</h1>
  <nav>
  <div class="nav nav-tabs" id="nav-tab" role="tablist">
    <a class="nav-item nav-link active " id="nav-profile-tab" data-toggle="tab" href="#nav-profile" role="tab" aria-controls="nav-profile" aria-selected="true">Profile</a>
    <a class="nav-item nav-link" id="nav-novel-tab" data-toggle="tab" href="#nav-novel" role="tab" aria-controls="nav-novel" aria-selected="false">Novels</a>

  </div>
</nav>
<div class="tab-content" id="nav-tabContent">
  <div class="tab-pane fade show active " id="nav-profile" role="tabpanel" aria-labelledby="nav-profile-tab"><img class="mr-4 mb-4" style="float: left ;width:350px;height: 400px" src="samaresh.jpg"><br>
   
<p class="mx-auto" style="color:white">
 <br> 

Date of Birth: 10 march 1944
<br>
Place of Birth: Jalpaiguri, India
<br><br>
Father: Kalipada Gangopaddhyay
<br>
Mother: Meera Gangopaddhyay
<br><br>
Nationality: Indian
<br><br>
Award: Ananda award (1982), literature academy award (1984),
<br><br>
Spouse: Swati Gangopaddhyay
<br><br>
Date of Death: October 23,2012
<br>
Place of Death: West Bengal
<br>
<br>
<br><br><br>
<div class="text-white">
<h3 style="color:#641016">Early life :</h3>
  Shamaresh Mazumdar spent his childhood years in the tea gardens of Dooars, Gairkata in Jalpaiguri district, West Bengal, India. He was a student of the Jalpaiguri Zilla School, Jalpaiguri. He completed his bachelor's in Bengali from Scottish Church College in Kolkata.Followed by a Masters in Bengali Literature from University of Calcutta.
<br><br><br>

<h3 style="color:#641016">Literary Career :</h3>
He was fond of Group Theatre very much. By writing a story ‘Onnomatra’ for a stage drama he started his writing career. Later in 1976, his first Desh published his first novel ‘Dour’. Besides, he also worked upon the short story, travel story, and teenage novels.<br><br>
Mazumdar is a versatile writer though many of his novels have a touch of thrill and suspense attached to them. His novels include Aath Kuthuri Noy Daraja, Bandinibash, Daybadhha, and Buno Haansher Palak. Perhaps his most famous novel is Saatkahon. Being a prolific writer who has excelled in different genres, Samares Mazumdar has worked on short stories, novels, travelogues and children's fiction. His quartet of Uttoradhikar, Kalbela Kalpurush and " Mousalkal" is now considered as a modern classic.<br><br><br>
<h3 style="color:#641016">Works :</h3>
Some of the famous literary works of this Bengali author include :
<br><br>
Dour – The first novel written by Samaresh Majumdar and published in 1976
<br><br>
Uttaradhikar – This is the story of Animesh a boy and then a youth who grows up in the tea gardens of North Bengal. This is the first of the Animesh trilogy.
<br><br>
Kalbela – In this novel, Animesh the hero arrives in Calcutta and struggles to adjust himself to Calutta's culture, politics and society. He is handicapped, and falls in love with Madhabilata a Bangladeshi girl whom he marries.
Samaresh Majumdar won the prestigious Sahitya Academy Award for Kalbela in 1984.
<br><br>
Kalpurush - The last of Animesh trilogy, this novel explores the conflict of Arko, the son of Animesh and Madhabilata, who tries to adjust between his parents idealisms and present day's consumerism.
<br><br>
Arjun is another sleuth cum science fiction character created by Samaresh Majumdar that though written for the younger readers is enjoyed across every age group.
<br><br>
Buno Hans is story of a ambitious young man who migrates to Thailand and then tries to setttle in Canada. All about him and his lady love makes the novel alive before the eyes of the readers.
<br><br>
Other novels of Samaresh Majumdar include Sharonagoto, Saat Kahon I and II and Tero Parbon. Swapner Bazar, Ujaan Ganga, Tirtha Jaatri, Victoriar Bagaan, Aat Kuthuri Noy Darja, Attiyoswajan, Anuraag, Cinemawallah, Derdin, Ekmukhi Rudraksha, Garbha Dharini and Ekadosh Aswarohi are some of the other books written by the great literary personality. Samaresh Majumdar has written about sixty novels and more than one hundred short stories that have left behind an indelible impression in the minds of thousands of Bengali readers.<br><br><br>
<h3 style="color:#641016">Awards And Achievements :</h3>
He achieved many national and international awards. He also got BFJA, Dishari and Chalachitra Prasar Samity award in 1982 for Best Script Writer. After that, Samaresh Majumdar received Bankim Puroshkar award for ‘Kolikatay Nobokumar’ in 2009.<br><br><br>

</div>
  </div>
  <div class="tab-pane fade" id="nav-novel" role="tabpanel" aria-labelledby="nav-novel-tab">

<?php

if(isset($_POST['search']))
{
    $valueToSearch = $_POST['valueToSearch'];
    // search in all table columns
    // using concat mysql function
    $query = "SELECT * FROM `samaresh majumdar` WHERE CONCAT( `name`, `writer`, `category`,`description`,`link`) LIKE '%".$valueToSearch."%'";
    $search_result = filterTable($query);
    
}
 else {
    $query = "SELECT * FROM `samaresh majumdar`";
    $search_result = filterTable($query);
}

// function to connect and execute the query
function filterTable($query)
{
    $connect = mysqli_connect("localhost", "root", "", "blog");
    $filter_Result = mysqli_query($connect, $query);
    return $filter_Result;
}

?>

 <form action="samaresh.php" method="post"> 
            <br><br>
             <table style="border: 2px solid #641016;" class="text-white text-center">
                <tr class="mx-4 ml-4 my-4">
                   
                    <th class="mr-4 ml-4 my-4">Name</th>
                    <th class="mr-4 ml-4 my-4">Writer</th>
                    <th class="mr-4 ml-4 my-4">Category</th>
                    <th class="corner wideRow">Description</th>
                    <th class="mr-4 ml-4 my-4">Link</th>
                </tr>

      <!-- populate table from mysql database -->
                <?php while($row = mysqli_fetch_array($search_result)):?>
                <tr class="mr-4 ml-4 my-4">
                    
                    <td style="font-weight: bolder" class="mr-4 ml-4 my-4"><?php echo $row['name'];?></td>
                    <td class="mr-4 ml-4 my-4"><?php echo $row['writer'];?></td>
                    <td class="mr-4 ml-4 my-4"><?php echo $row['category'];?></td>
                     <td class="mr-4 ml-4 my-4"><?php echo $row['description'];?></td>
                      <td class="mr-4 ml-4 my-4"><?php echo $row['link'];?></td>
                </tr>
                <?php endwhile;?>
            </table>
        </form>
  </div>




   <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/4.5.0/js/bootstrap.bundle.min.js"></script>
  
</main>
</div>
</body>