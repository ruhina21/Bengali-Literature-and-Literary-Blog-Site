  <!DOCTYPE html>
  <html>
  <head>
    <title>মালতী</title>
     <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
      <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.1/css/all.min.css">
      <link rel="stylesheet" href="/css/bootstrap-grid.min.css">
      <link rel="stylesheet" href="explr.css">
      <link rel="preconnect" href="https://fonts.gstatic.com">
        <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.1/css/all.min.css">
          <link rel="stylesheet" href="table.css">
      <link href="https://fonts.googleapis.com/css2?family=Big+Shoulders+Stencil+Text:wght@700&display=swap" rel="stylesheet">
      <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.1.3/css/bootstrap.min.css" integrity="sha384-MCw98/SFnGE8fJT3GXwEOngsV7Zt27NXFoaoApmYm81iuXoPkFOJwJ8ERdknLPMO" crossorigin="anonymous">
      <link rel="preconnect" href="https://fonts.gstatic.com">
<link href="https://fonts.googleapis.com/css2?family=Abril+Fatface&display=swap" rel="stylesheet">
<style>
  .nav-item{
  font-family: 'Abril Fatface', cursive;
}
</style>
<style>
  .nav-item{
    color: #641016;
    font-weight: bold;
font-family: 'Abril Fatface', cursive;
  }
  .nav-item:hover{
   color : yellow; 
   transform:scale(1.1);
  }
p{
  color: #ffffff;
}
h3{
 
  font-family: 'Abril Fatface', cursive;

}
table,tr,th,td
            {
                border: 2px solid #641016;
            }
            table td.wideRow, table th.wideRow {
  width: 500px;
}
th{

  color:yellow;
}
</style>
  </head>
  <body style="background-color:black" >
  <div class="container">
    <header class="mx-0 " >
      <nav class="navbar navbar-expand-md navbar-dark fixed-top">
    <a class="navbar-brand" href="http://localhost/project/projecting.php">
  <img src="6bfd6d9ed685fc2b0af4bed3f790c0ae.jpg" style="width:100px" class="rounded-circle"alt="Maloti">
      </a>
      <div class="collapse navbar-collapse" id="navbarNav">

    <ul class="navbar-nav ">

    <li class="nav-item">
       <button class="btn btn-lg bg-warning mr-3 " > <a class="nav-link" style="color: #641016" href="http://localhost/project/explore.php">AUTHOR LIST</a></button>
      </li>
     <li class="nav-item active font-weight-bolder">
        <button class="btn btn-lg  mr-3" style="font-weight: bolder ;background-color: yellow"><a class="nav-link" href="#" style="color: yellow;background-color: #641016">BOOK LIST<span class="sr-only">(current)</span></a></button>
      </li>
      <li class="nav-item">
        <button class="btn btn-lg bg-warning " ><a class="nav-link" href="http://localhost/project/add_rate.php" style="color: #641016">BLOG SECTION</a></button>
      </li>

     
    </ul>
  </div>
 
  </nav>
   </header>
<main>
 

<br><br><br><br><br><br><br>
<?php

if(isset($_POST['search']))
{
    $valueToSearch = $_POST['valueToSearch'];
    // search in all table columns
    // using concat mysql function
    $query = "SELECT * FROM `alltable` WHERE CONCAT( `name`, `writer`, `category`,`description`,`link`) LIKE '%".$valueToSearch."%'";
    $search_result = filterTable($query);
    
}
 else {
    $query = "SELECT * FROM `alltable`";
    $search_result = filterTable($query);
}

// function to connect and execute the query
function filterTable($query)
{
    $connect = mysqli_connect("localhost", "root", "", "blog");
    $filter_Result = mysqli_query($connect, $query);
    return $filter_Result;
}

?>

 <form action="Booklist.php" method="post"> 
            <input type="text" name="valueToSearch" placeholder="Search....">
            <input type="submit" name="search" value="Search"><br><br>
             <table style="border: 2px solid #641016;" class="text-white">
                <tr class="my-4">
                   
                    <th>Name</th>
                    <th>Writer</th>
                    <th>Category</th>
                    <th class="corner wideRow">Description</th>
                    <th>Link</th>
                </tr>

      <!-- populate table from mysql database -->
                <?php while($row = mysqli_fetch_array($search_result)):?>
                <tr>
                    
                    <td style="font-weight: bolder"><?php echo $row['name'];?></td>
                    <td><?php echo $row['writer'];?></td>
                    <td><?php echo $row['category'];?></td>
                     <td><?php echo $row['description'];?></td>
                      <td><?php echo $row['link'];?></td>
                </tr>
                <?php endwhile;?>
            </table>
        </form>


</main>
  </div>

  <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js" integrity="sha384-DfXdz2htPH0lsSSs5nCTpuj/zy4C+OGpamoFVy38MVBnE+IbbVYUew+OrCXaRkfj" crossorigin="anonymous"></script>
            <script src="https://cdn.jsdelivr.net/npm/bootstrap@4.5.3/dist/js/bootstrap.bundle.min.js" ntegrity="sha384-ho+j7jyWK8fNQe+A12Hb8AhRq26LrZ/JpcUGGOn+Y7RsweNrtN/tE3MoK7ZeZDyx" crossorigin="anonymous"></script>
            <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js" integrity="sha384-DfXdz2htPH0lsSSs5nCTpuj/zy4C+OGpamoFVy38MVBnE+IbbVYUew+OrCXaRkfj" crossorigin="anonymous"></script>
            <script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.1/dist/umd/popper.min.js" integrity="sha384-9/reFTGAW83EW2RDu2S0VKaIzap3H66lZH81PoYlFhbGU+6BZp6G7niu735Sk7lN" crossorigin="anonymous"></script>
            <script src="https://cdn.jsdelivr.net/npm/bootstrap@4.5.3/dist/js/bootstrap.min.js" integrity="sha384-w1Q4orYjBQndcko6MimVbzY0tgp4pWB4lZ7lr30WKz0vr/aWKhXdBNmNb5D92v7s" crossorigin="anonymous"></script>
  </body>
  </html>