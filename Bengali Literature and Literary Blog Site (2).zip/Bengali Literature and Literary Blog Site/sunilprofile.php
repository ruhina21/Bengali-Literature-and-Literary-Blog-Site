
<!DOCTYPE html>
  <html>
  <head>
    <title>Sunil Gangopaddhyay</title>
     <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
      <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.1/css/all.min.css">
      <link rel="stylesheet" href="/css/bootstrap-grid.min.css">
      <link rel="stylesheet" href="explr.css">
      <link rel="preconnect" href="https://fonts.gstatic.com">
        <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.1/css/all.min.css">
      <link href="https://fonts.googleapis.com/css2?family=Big+Shoulders+Stencil+Text:wght@700&display=swap" rel="stylesheet">
      <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.1.3/css/bootstrap.min.css" integrity="sha384-MCw98/SFnGE8fJT3GXwEOngsV7Zt27NXFoaoApmYm81iuXoPkFOJwJ8ERdknLPMO" crossorigin="anonymous">
       <link rel="stylesheet" href="table.css">
      <link rel="preconnect" href="https://fonts.gstatic.com">
<link href="https://fonts.googleapis.com/css2?family=Abril+Fatface&display=swap" rel="stylesheet">
<style>
  .nav-item{
    color: #641016;
    font-weight: bold;
font-family: 'Abril Fatface', cursive;
  }
  .nav-item:hover{
   color : yellow; 
   transform:scale(1.1);
  }
p{
  color: #ffffff;
}
i{
  color:grey;
  width: 50%;
}
h3{
 
  font-family: 'Abril Fatface', cursive;

}
table,tr,th,td
            {
                border: 2px solid #641016;

            }
            table td.wideRow, table th.wideRow {
  width: 500px;
}
th{

  color:yellow;
}
</style>
  </head>
  <body style="background-color:black" >
  <div class="container">
    <header class="mx-0 " >
      <nav class="navbar navbar-expand-md navbar-dark fixed-top">
    <a class="navbar-brand" href="http://localhost/project/projecting.php">
  <img src="6bfd6d9ed685fc2b0af4bed3f790c0ae.jpg" style="width:100px" class="rounded-circle"alt="Maloti">
      </a>
      <div class="collapse navbar-collapse" id="navbarNav">

    <ul class="navbar-nav ">

       <li class="nav-item active font-weight-bolder">
       <button class="btn btn-lg  mr-3 " style="font-weight: bolder ;background-color: yellow"> <a class="nav-link" style="color: yellow;background-color: #641016" href="http://localhost/project/explore.php">AUTHOR LIST<span class="sr-only">(current)</span></a></button>
     </li>
     <li class="nav-item ">
       <button class="btn btn-lg bg-warning mr-3 " > <a class="nav-link" style="color: #641016" href="http://localhost/project/Booklist.php">BOOK LIST</a></button>
      </li>
      <li class="nav-item">
        <button class="btn btn-lg bg-warning " ><a class="nav-link" href="http://localhost/project/upload.php" style="color: #641016">BLOG SECTION</a></button>
      </li>

     
    </ul>
  </div>
  <img src="sunil.jpg" class="rounded-circle " style="height: 70px" >
</nav>
</header>

<main>
  <br> <br> <br> <br><br><br><br>
   <h1 style=" color: #641016; font-family: 'Big Shoulders Stencil Text', cursive;" class="text-center">Sunil Gangopaddhyay</h1>
  <nav>
  <div class="nav nav-tabs" id="nav-tab" role="tablist">
    <a class="nav-item nav-link active " id="nav-profile-tab" data-toggle="tab" href="#nav-profile" role="tab" aria-controls="nav-profile" aria-selected="true">Profile</a>
    <a class="nav-item nav-link" id="nav-novel-tab" data-toggle="tab" href="#nav-novel" role="tab" aria-controls="nav-novel" aria-selected="false">Novels</a>

  </div>
</nav>
<div class="tab-content" id="nav-tabContent">
  <div class="tab-pane fade show active " id="nav-profile" role="tabpanel" aria-labelledby="nav-profile-tab"><img class="mr-4 mb-4" style="float: left ;width:400px;height: 400px" src="sunil1.jpg"><br>
   
<p class="mx-auto" style="color:white">
 <br> 

Date of Birth:  7 September 1934 
<br>
Place of Birth: Faridpur, Bengal Presidency, British India (now in Bangladesh)
<br><br>
Father: Kalipada Gangopaddhyay
<br>
Mother: Meera Gangopaddhyay
<br><br>
Title : Nil Lohit
<br><br>
Spouse: Swati Gangopaddhyay
<br><br>
Date of Death: October 23,2012
<br>
Place of Death: West Bengal
<br>
<br>
<br><br><br>
<div class="text-white">
<h3 style="color:#641016">Early life :</h3>
  Sunil Gangopadhyay was born in Faridpur, present day Bangladesh. He moved to Calcutta when he was only four years old. From 1953, he started editing a poetry magazine called Krittibas. His first book of poetry, Alone and a Few (একা এবং কয়েকজন), was published in 1958, and his first novel was published in 1986.
An anecdote about Sunil Gangopadhyay doing the rounds is that he had gifted his first novel to an associate, saying that if the book was not readable it could at least come of use when pushed under a wobbly desk. His books instead landed up in best-seller lists.Sunil Gangopadhyay was from a Hindu family. His father’s name was Kalipada Gagopadhyay and her mother was Mira Gangopadhyay.Sunil Ganguly had a Graduate Degree in Bengali. He studied at 3 collages they are Surendranath College, Dum Dum Motijheel College, City College, Kolkata all are under Calcutta University. Swati Bandopadhyay was her wife and he also had a son named, Souvik Gangopadhyay.
<br><br><br>

<h3 style="color:#641016">Literary Career :</h3>
Sunil’s father Kalipada Gagopadhyay told him with a book of Tennyson‘s poems that he would translate two poems every day. It was done so that he could not go out at noon. He did so. He used to translate poems at noon with his father’s command.
When the translation became boring, he started writing himself. The poem, which was addressed to his childhood sweetheart, was published when he sent it to the country.
Next, he wrote many Poems, Novels, Short stories and others. His writing is really popular and creative, so many films and TV shows are made on his works. Here are some of his popular works.<br><br>
Two generations of Bengalis have grown up reading the poetry and prose of the prolific Sunil Gangopadhyay — his works “a perfect statement” of the experiences one encounters between adolescence and adulthood.
In the world of the unfettered imagination of his creation — both the fantasies and the realities that he wrote of — resonated with the youth. When he wrote about a mythical woman, he could recreate the fantasies that one dreams of and the rather prosaic realities of the actual experience, believes Arunava Sinha, who has translated a collection of his poems, For Nira, Suddenly and the recently published Wonderworld and Other Stories. 
<i>“His best writing has a lot to do with the language itself. The words or turn of phrase he used would itself have an emotional impact. As a translator, one had to be very sensitive to these,” Mr. Sinha said.</i>
Said filmmaker Goutam Ghose, whose critically acclaimed film Moner Manush was based on a novel by the author: <i>“Sunil Gangopadhyay carried the modern consciousness of Bengal.”</i>
Recounting how the novel — a biography of Lalan Fakir — was conceptualised, Mr. Ghose said he had often had long discussions with the writer on the philosophy of the Baul singer.
<i>“As developments such as the demolition of the Babri Masjid and the spread of a culture of intolerance occurred, I would often tell him to write about Lalan Fakir. He would say that he would do so when the time came. And one day I found that he had indeed written it. I read it in one breath and immediately knew I would make a film on it,”</i> Mr. Ghose said.
Starting off his six-decade literary career as a bohemian poet and editor of Kritibas, a monthly poetry magazine, Sunil Gangopadhyay wrote his first novel, Athmo Prakash (Self-Revelation), at the behest of the editor of the hugely popular periodical Desh for its special Durga Puja edition.
He wrote many other novels, short stories, travelogues, children’s book — more than 200 of them — but poetry remained his “first love.”<br><br><br>
<h3 style="color:#641016">Transition :</h3>
From the mid 1980s, his poetry was no longer the same. It wasn’t the same voice and he himself candidly said “ Kabita ar ashe na” (the poems no longer come to me).Convinced that Sunil Gangopadhyay would have received much more acclaim across the country had his works been translated into English when he was at the peak of his abilities, Mr. Sinha pointed out that the early translations of his works were actually through films.

Two of the most critically acclaimed films of legendary filmmaker Satyajit Ray — Pratidwandi and Aranyer Din Ratri — were based on novels written by him. “They were primarily known as the works of the director, but a small subset of the viewers would have been aware who the writer was,” he said.
<i>
“We two were the last two living authors whose novels were used by the maestro [Satyajit Ray],” said Mani Shankar Mukherjee, a contemporary of Sunil Gangopadhyay.</i><br><br><br>

<h3 style="color:#641016">Seminal Works :</h3>
As readers of Bengali literature eagerly awaited the special editions during the Durga Puja festival, wanting to know what Sunil Gangopadhyay had on offer for that season, his three epics — Shei Shomay (Those Days), Pratham Alo (First Light)and Purba Pachim (East and West) that were first published in a serialised form — captured the imagination of readers for about 15 years, Mr. Sinha said.
<br><br>
Shei Shomay won him the Sahitya Akademi Award in 1985. More than two decades later, in 2008, Sunil Gangopadhyay was elected the president of the Akdemi.

A work of historical fiction, in Shei Shomay he took considerable liberties with real life characters, some of whom were revered figures. But it was his skill of weaving in the details of the period with the plot of a thoroughly enjoyable novel, said Mr. Ghose.
<br><br><br>
<h3 style="color:#641016">Awards And Achievements :</h3>
He got many awards because of his great works, here are some of them: Ananda Puraskar, Bankim Puraskar for the book Sei Somoy, Sahitya Akademi Award for the book Sei Somoy, Sahitya Setu puroskar, Annadashankar puroskar, Saraswati Samman, The Hindu Literary Prize, Sera Bangali Lifetime Achievement Award and many more.
In 2002, Sunil Gangopadhyay was elected Sheriff of Calcutta. He was awarded the Ananda Award in 1982 and 1989 and the Sahitya Academy Award in 1985.<br><br><br>
<h3 style="color:#641016">Death :</h3>
He died on 23 October, 2012 due to a heart attack. On April 4, 2003, Sunil Gangopadhyay donated his wife’s body to Ganadarpan in Kolkata.

But his body was cremated at the behest of Souvik Gangopadhyay, the only son of Sunil Gangopadhyay. His last rites were performed on 25 October 2012 under the management of the Government of West Bengal.
At the time of his death, the writer was in the midst of writing a serialised version of Chotoder Mahabharat (Mahabharat for children), a project he was very keen on. The children’s version of the epic, which had appeared in a leading magazine for over a year, remains incomplete.<br>
<i>

“For India, the death of Sunil Gangopadhyay is the loss of a great writer. At a personal level, I have lost a great friend,” </i>said poet Shankha Ghosh, who knew the writer for over 60 years.

Indeed, it was a deep sense of personal loss that was expressed by several well known personalities though the day. Recalling the addas (discussions) with Sunil Gangopadhyay, Mr. Ghose said that often he would decide to end them with a song.<br><br>
<i>
“We would say, ‘Oh! It is time for Sunil giti (songs of Sunil) as opposed to Rabindra sangeet (songs of Tagore) or Nazrul giti (songs of Nazrul).’</i> And he would then dig out a song by Tagore or a Baul song and we would end the adda with it,” he said.


</div>
  </div>
  <div class="tab-pane fade" id="nav-novel" role="tabpanel" aria-labelledby="nav-novel-tab">

<?php

if(isset($_POST['search']))
{
    $valueToSearch = $_POST['valueToSearch'];
    // search in all table columns
    // using concat mysql function
    $query = "SELECT * FROM `sunilnovel` WHERE CONCAT( `name`, `writer`, `category`,`description`,`link`) LIKE '%".$valueToSearch."%'";
    $search_result = filterTable($query);
    
}
 else {
    $query = "SELECT * FROM `sunilnovel`";
    $search_result = filterTable($query);
}

// function to connect and execute the query
function filterTable($query)
{
    $connect = mysqli_connect("localhost", "root", "", "blog");
    $filter_Result = mysqli_query($connect, $query);
    return $filter_Result;
}

?>

 <form action="sunilprofile.php" method="post"> 
            <br><br>
             <table style="border: 2px solid #641016;" class="text-white text-center">
                <tr class="mx-4 ml-4 my-4">
                   
                    <th class="mr-4 ml-4 my-4">Name</th>
                    <th class="mr-4 ml-4 my-4">Writer</th>
                    <th class="mr-4 ml-4 my-4">Category</th>
                    <th class="corner wideRow">Description</th>
                    <th class="mr-4 ml-4 my-4">Link</th>
                </tr>

      <!-- populate table from mysql database -->
                <?php while($row = mysqli_fetch_array($search_result)):?>
                <tr class="mr-4 ml-4 my-4">
                    
                    <td style="font-weight: bolder" class="mr-4 ml-4 my-4"><?php echo $row['name'];?></td>
                    <td class="mr-4 ml-4 my-4"><?php echo $row['writer'];?></td>
                    <td class="mr-4 ml-4 my-4"><?php echo $row['category'];?></td>
                     <td class="mr-4 ml-4 my-4"><?php echo $row['description'];?></td>
                      <td class="mr-4 ml-4 my-4"><?php echo $row['link'];?></td>
                </tr>
                <?php endwhile;?>
            </table>
        </form>
  </div>




   <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/4.5.0/js/bootstrap.bundle.min.js"></script>
  
</main>
</div>
</body>