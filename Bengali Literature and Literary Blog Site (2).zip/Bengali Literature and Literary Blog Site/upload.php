<!DOCTYPE html>
<html>
<head>
	<br><br><br><br><br><br>
	<style >
		.section-title{
			 font-family: 'Big Shoulders Stencil Text', cursive;
			 color: #641016;
		}

	</style>
</head>
<body>
<div class="section-title py-3">
        <h1 class="text-center " >BLOGS</h1>
        </div>
</body>
</html>
<?php 

$localhost = "localhost"; #localhost
$dbusername = "root"; #username of phpmyadmin
$dbpassword = "";  #password of phpmyadmin
$dbname = "ruhina";  #database name
 
#connection string

$conn = mysqli_connect($localhost,$dbusername,$dbpassword,$dbname);
if(isset($_REQUEST["submit"]))
{
	 $file=$_FILES["file"]["name"];
	$tmp_name=$_FILES["file"]["tmp_name"];
	$path="uploads/".$file;
	$file1=explode(".",$file);
	$ext=$file1[1];
	$allowed=array("jpg","png","gif","pdf","wmv","pdf","zip");
	if(in_array($ext,$allowed))
	{
 move_uploaded_file($tmp_name,$path);

	$sql = "INSERT into myblob(file) VALUES('$file')";
	 if(mysqli_query($conn,$sql)){
 
    echo "File Sucessfully uploaded";
    }
    else{
        echo "Error";
    }

	
}
}


$query=mysqli_query($conn,"select * from myblob");
$rowcount=mysqli_num_rows($query);
?>
<br>

<table border="3" class="bg-warning ml-auto mr-auto">
	 <thead class="thead-dark">
    <tr style="height: 60px">
<th class="text-center  bg-warning" style="color:#641016" >Click on the file to read the blog for Free !</th>
</tr>
  </thead>

<?php
for($i=1;$i<=$rowcount;$i++)
{
	$row=mysqli_fetch_array($query);

?>
<tr style="background-color:#641016 ">
<td style="height: 30px" ><a href="uploads/<?php echo $row["file"] ?>"><?php echo $row["file"] ?></a></td>

</tr>

<?php	
}

?>
</table>

	<!DOCTYPE html>
	
	<head>
		<title>maloti</title>
		 <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
	    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.1/css/all.min.css">
	    <link rel="stylesheet" href="/css/bootstrap-grid.min.css">
	    <link rel="stylesheet" href="explr.css">
	    <link rel="preconnect" href="https://fonts.gstatic.com">
	      <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.1/css/all.min.css">
	    <link href="https://fonts.googleapis.com/css2?family=Big+Shoulders+Stencil+Text:wght@700&display=swap" rel="stylesheet">
	    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.1.3/css/bootstrap.min.css" integrity="sha384-MCw98/SFnGE8fJT3GXwEOngsV7Zt27NXFoaoApmYm81iuXoPkFOJwJ8ERdknLPMO" crossorigin="anonymous">
	    <link href="https://fonts.googleapis.com/css2?family=Abril+Fatface&display=swap" rel="stylesheet">
<style>
	a{
		color: yellow;
	}
	a:hover{
		color:black;
		 transform:scale(1.1);
  
	}
	.nav-item{
  font-family: 'Abril Fatface', cursive;
}
</style>
	</head>
	<body style="background-color:black" >
	<div class="container">
		<header class="mx-0 " >
	    <nav class="navbar navbar-expand-md navbar-dark fixed-top">
	  <a class="navbar-brand" href="http://localhost/project/projecting.php">
	<img src="6bfd6d9ed685fc2b0af4bed3f790c0ae.jpg" style="width:100px" class="rounded-circle"alt="Maloti">
      </a>
      <div class="collapse navbar-collapse" id="navbarNav">

    <ul class="navbar-nav ">

      <li class="nav-item ">
       <button class="btn btn-lg bg-warning mr-3 " > <a class="nav-link" style="color: #641016" href="http://localhost/project/explore.php">AUTHOR LIST<span class="sr-only">(current)</span></a></button>
      </li>
     <li class="nav-item ">
       <button class="btn btn-lg bg-warning mr-3 " > <a class="nav-link" style="color: #641016" href="http://localhost/project/Booklist.php">BOOK LIST</a></button>
      </li>
      <li class="nav-item active font-weight-bolder">
        <button class="btn btn-lg  " style="font-weight: bolder ;background-color: yellow"><a class="nav-link" href="#" style="color: yellow;background-color: #641016">BLOG SECTION</a></button>
      </li>

     
    </ul>
  </div>
	
	</nav>
	 </header>
<main>
	<br><br><br><br><br><br><br><br>
  <section id="Blog">
    <div class="section-title py-3">
        <h1 class="text-center" style="text:#c30c02">Upload Your Blog</h1>
        </div>

<form method="post" enctype="multipart/form-data" class="bg-warning ">
    <label  class="mx-4 my-4"> Name :</label>
    <input type="text" name="Name" class="ml-4 my-4"><br><br><br>
    <label  class="mx-4 my-4" style="font-weight: bold" >File Upload :</label><br>
    <input  class="mx-4 my-4" type="File" name="file">
    <input type="submit" name="submit"  class="ml-4 my-4">
 
 
</form>
 

 



 
  </section>



</main>
	</div>

	<script src="https://code.jquery.com/jquery-3.5.1.slim.min.js" integrity="sha384-DfXdz2htPH0lsSSs5nCTpuj/zy4C+OGpamoFVy38MVBnE+IbbVYUew+OrCXaRkfj" crossorigin="anonymous"></script>
            <script src="https://cdn.jsdelivr.net/npm/bootstrap@4.5.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-ho+j7jyWK8fNQe+A12Hb8AhRq26LrZ/JpcUGGOn+Y7RsweNrtN/tE3MoK7ZeZDyx" crossorigin="anonymous"></script>
            <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js" integrity="sha384-DfXdz2htPH0lsSSs5nCTpuj/zy4C+OGpamoFVy38MVBnE+IbbVYUew+OrCXaRkfj" crossorigin="anonymous"></script>
            <script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.1/dist/umd/popper.min.js" integrity="sha384-9/reFTGAW83EW2RDu2S0VKaIzap3H66lZH81PoYlFhbGU+6BZp6G7niu735Sk7lN" crossorigin="anonymous"></script>
            <script src="https://cdn.jsdelivr.net/npm/bootstrap@4.5.3/dist/js/bootstrap.min.js" integrity="sha384-w1Q4orYjBQndcko6MimVbzY0tgp4pWB4lZ7lr30WKz0vr/aWKhXdBNmNb5D92v7s" crossorigin="anonymous"></script>
	</body>

</html>

