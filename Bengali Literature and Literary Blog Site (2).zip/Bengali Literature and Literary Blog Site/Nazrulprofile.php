
<!DOCTYPE html>
  <html>
  <head>Kazi NAzrul Islam</title>
     <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
      <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.1/css/all.min.css">
      <link rel="stylesheet" href="/css/bootstrap-grid.min.css">
      <link rel="stylesheet" href="explr.css">
      <link rel="preconnect" href="https://fonts.gstatic.com">
        <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.1/css/all.min.css">
      <link href="https://fonts.googleapis.com/css2?family=Big+Shoulders+Stencil+Text:wght@700&display=swap" rel="stylesheet">
      <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.1.3/css/bootstrap.min.css" integrity="sha384-MCw98/SFnGE8fJT3GXwEOngsV7Zt27NXFoaoApmYm81iuXoPkFOJwJ8ERdknLPMO" crossorigin="anonymous">
      <link rel="preconnect" href="https://fonts.gstatic.com">
       <link rel="stylesheet" href="table.css">
<link href="https://fonts.googleapis.com/css2?family=Abril+Fatface&display=swap" rel="stylesheet">
<style>
  .nav-item{
    color: #641016;
    font-weight: bold;
font-family: 'Abril Fatface', cursive;
  }
  .nav-item:hover{
   color : yellow; 
   transform:scale(1.1);
  }
p{
  color: #ffffff;
}
i{
  color:grey;
  width: 50%;
}
h3{
 
  font-family: 'Abril Fatface', cursive;

}
table,tr,th,td
            {
                border: 2px solid #641016;
            }
            table td.wideRow, table th.wideRow {
  width: 500px;
}
th{

  color:yellow;
}
</style>
  </head>
  <body style="background-color:black" >
  <div class="container">
    <header class="mx-0 " >
      <nav class="navbar navbar-expand-md navbar-dark fixed-top">
    <a class="navbar-brand" href="http://localhost/project/projecting.php">
  <img src="6bfd6d9ed685fc2b0af4bed3f790c0ae.jpg" style="width:100px" class="rounded-circle"alt="Maloti">
      </a>
      <div class="collapse navbar-collapse" id="navbarNav">

    <ul class="navbar-nav ">

      <li class="nav-item active font-weight-bolder">
       <button class="btn btn-lg  mr-3 " style="font-weight: bolder ;background-color: yellow"> <a class="nav-link" style="color: yellow;background-color: #641016" href="http://localhost/project/explore.php">AUTHOR LIST<span class="sr-only">(current)</span></a></button>
     </li>
     <li class="nav-item ">
       <button class="btn btn-lg bg-warning mr-3 " > <a class="nav-link" style="color: #641016" href="http://localhost/project/Booklist.php">BOOK LIST</a></button>
      </li>
      <li class="nav-item">
        <button class="btn btn-lg bg-warning " ><a class="nav-link" href="http://localhost/project/upload.php" style="color: #641016">BLOG SECTION</a></button>
      </li>

     
    </ul>
  </div>
  <img src="kazi.jpg" class="rounded-circle " style="height: 70px" >
</nav>
</header>

<main>
  <br> <br> <br> <br><br><br><br>
   <h1 style=" color: #641016; font-family: 'Big Shoulders Stencil Text', cursive;" class="text-center">Kazi Nazrul Islam</h1>
  <nav>
  <div class="nav nav-tabs" id="nav-tab" role="tablist">
    <a class="nav-item nav-link active " id="nav-profile-tab" data-toggle="tab" href="#nav-profile" role="tab" aria-controls="nav-profile" aria-selected="true">Profile</a>
    <a class="nav-item nav-link" id="nav-novel-tab" data-toggle="tab" href="#nav-novel" role="tab" aria-controls="nav-novel" aria-selected="false">Novel</a>
    <a class="nav-item nav-link" id="nav-poetry-tab" data-toggle="tab" href="#nav-poetry" role="tab" aria-controls="nav-poetry" aria-selected="false">Poetry</a>
  
     <a class="nav-item nav-link" id="nav-essay-tab" data-toggle="tab" href="#nav-essay" role="tab" aria-controls="nav-essay" aria-selected="false">Essay</a>
  </div>
</nav>
<div class="tab-content" id="nav-tabContent">
  <div class="tab-pane fade show active " id="nav-profile" role="tabpanel" aria-labelledby="nav-profile-tab"><img class="mr-4 mb-4" style="float: left ;width:350px;height: 400px" src="nazrul.jpg"><br>
   
<p class="mx-auto" style="color:white">
 <br> 

Date of Birth: May 24, 1899
<br>
Place of Birth: Churulia, Burdwan(at present West Bengal)
<br><br>
Father: Kazi Fakir Ahmed
<br>
Mother: Zaheda Khatun
<br><br>
Title : Rebel Poet
<br><br>
Spouse: Pramila Devi
<br><br>
Date of Death: August 29, 1976
<br>
Place of Death: Dhaka
<br>
<br>
<br><br><br>
<div class="text-white">
<h3 style="color:#641016">Early life :</h3>

Kazi Nazrul Islam was born in the village of Churulia in the Burdwan District of Bengal (now located in the Indian state of West Bengal). Second of three sons and a daughter, Nazrul's father, Kazi Fakir Ahmed was the imam and caretaker of the local mosque and mausoleum. Nazrul's mother was Zaheda Khatun. Nazrul had two brothers, Kazi Shahebjan and Kazi Ali Hussain, and a sister, Umme Kulsum. Nicknamed Dukhu Mia ("Sad Man"), Nazrul began attending the maktab — the local religious school run by the mosque — where he studied the Qur'an and other scripture, Islamic philosophy and theology. His family was devastated with the death of his father in 1908. At the young age of ten, Nazrul began working in his father's place as a caretaker to support his family, as well as assisting teachers in school. He later became the muezzin at the mosque, leading the community prayers.
<br><br>
Attracted to folk theater, Nazrul joined a leto (travelling theatrical group) run by his uncle Bazle Karim. Working and traveling with them, learning acting, as well as writing songs and poems for the plays and musicals. Through his work and experiences, Nazrul began learning Bengali and Sanskrit literature, as well as Hindu scriptures such as the Puranas. The young poet composed a number of folk plays for his group, which included Chasar San, Shakunibadh, Raja Yudhisthirer San, Data Karna, Akbar Badshah, Kavi Kalidas, Vidyabhutum, Rajputrer San, Buda Saliker Ghade Ron and Meghnad Badh.
<br><br>
In 1910, Nazrul left the troupe, enrolling in the Raniganj Searsole Raj School, and later transferred to the Mathrun High English School, studying under the headmaster and poet Kumudranjan Mallik. Unable to continue paying his school fees, Nazrul left the school and joined a group of “kaviyals.” Later he took jobs as a cook at the house of a Christian railway guard and at a bakery and tea stall in the town of Asansol. In 1914, Nazrul joined the Darirampur School in Trishal, Mymensingh District. Amongst other subjects, Nazrul studied Bengali, Sanskrit, Arabic, Persian literature and classical music under teachers who were impressed by his dedication and skill.
<br><br>
Studying up to Class X, Nazrul did not to appear for the matriculation pre-test examination, enlisting instead in the Indian Army in 1917. Some historians have conjectured that Nazrul may have wished to obtain military training with the aim of using it later for pursuing Indian independence. Attached to the 49th Bengal Regiment, he was posted to the cantonment in Karachi, where he wrote his first prose and poetry. Although he never saw active fighting, he rose in rank from corporal to havildar, and served as quartermaster for his battalion. During this period, Nazrul read extensively, and was deeply influenced by Rabindranath Tagore and Sarat Chandra Chattopadhyay, as well as the Persian poet Hafiz. He learned Persian poetry from the regiment's Punjabi moulvi, practiced music and pursued his literary interests. His first prose work, Baunduler Atmakahini (Life of a Vagabond) was published in May, 1919. His poem "Mukti" ("Freedom") was published by the "Bangla Mussalman Sahitya Patrika" ("Bengali Muslim Literary Journal") in July 1919.
<br><br><br><br>
<h3 style="color:#641016">Rebel Poet :</h3>

Nazrul left the army in 1920 and settled in Kolkata, which was then the Cultural capital of India (it had ceased to be the political capital in 1911). He joined the staff of the “Bangiya Mussalman Sahitya Samiti” ("Bengali Muslim Literary Society") and roomed at 32 College Street with colleagues. He published his first novel Bandhan-hara (Freedom from bondage) in 1920, which he kept working on over the next seven years. His first collection of poems included "Bodhan,” "Shat-il-Arab," "Kheya-parer Tarani" and "Badal Prater Sharab." Both works received critical acclaim, giving the young poet his first taste of fame.
<br><br>
Working at the literary society, Nazrul grew close to a rising generation of Muslim writers including Mohammad Mozammel Haq, Afzalul Haq, Kazi Abdul Wadud and Muhammad Shahidullah. He was a regular at clubs for Calcutta's writers, poets and intellectuals like the Gajendar Adda and the Bharatiya Adda. In October 1921, Nazrul went to Santiniketan with Muhammad Shahidullah and met Rabindranath Tagore. Despite many differences, Nazrul looked to Tagore as a mentor and the two remained in close association. In 1921, Nazrul was engaged to be married to Nargis, the niece of a well-known Muslim publisher Ali Akbar Khan, in Daulatpur, Comilla District. But on June 18, 1921 — the day of the wedding — the plans fell through. Upon public insistence by Ali Akbar Khan that the terms of the marriage contract be altered to include a requirement that Nazrul must reside in Daulatpur after wedding, Nazrul walked away from the ceremony. 
<br><br>
Nazrul catapulted to fame with the publication of "Bidrohi" in 1922, which remains his most famous work. At the time of publication, no other poem since Tagore's "Shonar tori" had met with such spontaneous acclaim and criticism for its radical approach. Set in a heroic meter, this long poem invokes images from Hindu, Muslim and Greek mythology. Nazrul won admiration of India's literary classes by his description of the rebel whose impact is fierce and ruthless even as its spirit is deep:
<br><br>
<i>
I am the unutterable grief,<br><br>
I am the trembling first touch of the virgin,<br>
I am the throbbing tenderness of her first stolen kiss.<br>
I am the fleeting glace of the veiled beloved,<br>
I am her constant surreptitious gaze….<br>
<br><br>
I am the burning volcano in the bosom of the earth,<br>
I am the wild fire of the woods,<br>
I am Hell's mad terrific sea of wrath!<br>
I ride on the wings of the lightning with joy and profound,<br>
I scatter misery and fear all around,<br>
I bring earth-quakes on this world!<br>
<br><br>
I am the rebel eternal,<br>
I raise my head beyond this world,<br>
High, ever erect and alone!<br>
  <br><br>
-English translation by Kabir Choudhary<br>
</i>
<br><br><br>
Published in the "Bijli" magazine, the poem caused a popular sensation. Nazrul stormed into Tagore's residence, jokingly declaring "Gurudev, I have come to kill you off." The rebellious language and theme found resonance with public consciousness of the time, which correlated with the Non-cooperation movement — the first, mass nationalist campaign of civil disobedience against British rule. Nazrul explores a synthesis of different forces in a rebel, destroyer and preserver, expressing rage as well as beauty and sensitivity. Nazrul followed up by writing "Pralayollas" ("Destructive Euphoria"), and his first anthology of poems, the "Agniveena" ("Lyre of Fire") in 1922, which enjoyed astounding and far-reaching success. He also published his first volume of short stories, the "Byather Dan" ("Gift of Sorrow") and "Yugbani,” an anthology of essays.
<br><br>

Nazrul started a bi-weekly magazine, publishing the first "Dhumketu" on August 12, 1922. Earning the moniker of the "rebel poet,” Nazrul also aroused the suspicion of British authorities.[8] A political poem published in "Dhumketu" in September 1922 led to a police raid on the magazine's office. Arrested, Nazrul entered a lengthy plea before the judge in the court.
<br><br>
I have been accused of sedition. That is why I am now confined in the prison. On the one side is the crown, on the other the flames of the comet One is the king, sceptre in hand; the other Truth worth the mace of justice. To plead for me, the king of all kings, the judge of all judges, the eternal truth the living God…. His laws emerged out of the realisation of a universal truth about mankind. They are for and by a sovereign God. The king is supported by an infinitesimal creature; I by its eternal and indivisible Creator. I am a poet; I have been sent by God to express the unexpressed, to portray the unportrayed. It is God who is heard through the voice of the poet…. My voice is but a medium for Truth, the message of God…. I am the instrument of that eternal self-evident truth, an instrument that voices forth the message of the ever-true. I am an instrument of God. The instrument is not unbreakable, but who is there to break God?
<br><br>

On April 14, 1923 he was transferred from the jail in Alipore to Hooghly in Kolkata, he began a 40-day fast to protest mistreatment by the British jail superintendent. Nazrul broke his fast more than a month later and was eventually released from prison in December 1923. Nazrul composed a large number of poems and songs during the period of imprisonment and many his works were banned in the 1920s by the British authorities. 
<br><br>
Kazi Nazrul Islam became a critic of the Khilafat struggle, condemning it as hollow, religious fundamentalism even as thousands of Muslims agitated for it. Nazrul's rebellious expression extended to rigid orthodoxy in the name of Islam. While explicitly avowing his affinity to Islam, and calling for upholding Islam for its universalistic essence, values and spirit, he believed that medieval Islamic practices and religious conservatism were hurting Indian Muslims as well as the Muslim world, and keeping them backward, intensifying social and sectarian challenges.Nazrul also criticized the Indian National Congress for not embracing outright political independence from the British Empire. Nevertheless, he became active in encouraging people to agitate against British rule, and joined the Bengal state unit of the Congress. Nazrul also helped organize the Sramik Praja Swaraj Dal, a political party committed to national independence and the service of the peasant masses. On December 16, 1925 Nazrul started publishing the weekly "Langal,” with himself as chief editor. The "Langal" was the mouthpiece of the Sramik Praja Swaraj Dal.
<br><br>
It was during his visit to Comilla in 1921, that Nazrul met a young Hindu woman, Pramila Devi. The two maintained regular correspondence. Falling in love, they married on April 25, 1924. Pramila belonged to the Brahmo Samaj, which criticized her marriage to a Muslim. Nazrul in turn was condemned by Muslim religious leaders and continued to face criticism for his personal life and professional works. As a result, Nazrul's works began intensely attacking social and religious dogma and intolerance. His poems also spoke in philosophical terms of romantic love, and the complete equality of men and women, and attacking the social and religious traditions of the time that ruled otherwise. Nazrul came to identify the spirit of his thoughts and works as inherently rebellious:
<i><br><br>
Weary of struggles, I, the great rebel,<br>
Shall rest in quiet only when I find<br>
The sky and the air free of the piteous groans of the oppressed.<br>
Only when the battle fields are cleared of jingling bloody sabres<br>
Shall I, weary of struggles, rest in quiet.</i><br><br><br><br>
<h3 style="color:#641016">Mass Music :</h3>

Nazrul on a hunting trip with friends in Sundarpur, India.
With his wife and young son Bulbul, Nazrul settled in Krishnanagar in 1926. His work began to transform as he wrote poetry and songs that articulated the aspirations of the downtrodden masses. Nazrul assailed the socio-economic norms and political system that had brought upon misery. The songs of Nazrul giving voice to the aspirations of the masses have come to known as "mass music." His major poems include "Daridro" ("Poverty"):
<br><br>
<i>
O poverty, thou hast made me great.<br>
Thou hast made me honoured like Christ<br>
With his crown of thorns. Thou hast given me<br>
Courage to reveal all. To thee I owe<br>
My insolent, naked eyes and sharp tongue.<br>
Thy curse has turned my violin to a sword...<br>
O proud saint, thy terrible fire<br>
Has rendered my heaven barren.<br>
O my child, my darling one<br>
I could not give thee even a drop of milk<br>
No right have I to rejoice.<br>
Poverty weeps within my doors forever<br>
As my spouse and my child.<br>
Who will play the flute?<br>
</i>
<br><br>
In what his contemporaries regarded as one of his greatest flairs of creativity, Nazrul began composing the very first ghazals in Bengali, transforming a form of poetry written mainly in Persian and Urdu.[4] While hailed by many as a pioneer and epoch-making poet by progressives, who took inspiration from his works that attacked traditions and dogma on behalf of the masses, he was also derided by many as an irreligious influence on society.[12] Arousing controversy and passions in his readers, Nazrul's ideas attained great popularity across India. In 1928, Nazrul began working as a lyricist, composer and music director for His Master's Voice Gramophone Company. The songs written and music composed by him were broadcast on radio stations across the country. He was also recruited by the Indian Broadcasting Company.
<br><br>

Nazrul professed faith in the absolute equality of women — a view his contemporaries considered revolutionary. In his poem "Naree" ("Women"), Nazrul repudiates what he sees as the long-standing oppression of women, proclaiming their equality:
<br><br>
<i>
Whatever great or benevolent achievements<br>
That are in this world<br>
Half of that was by woman<br>
The other half by man.<br>
</i><br><br>
However, most of his descriptions of women do not extend beyond domestic roles.[14] His poetry retains long-standing notions of men and women in binary opposition to one another and does not affirm gender similarities and flexibility in the social structure:
<i><br><br>
Man has brought the burning, scorching heat of the sunny day;<br>
Woman has brought peaceful night, soothing breeze and clou<br>d.<br>
Man comes with desert-thirst; woman provides the drink of honey.<br>
Man ploughs the fertile land; woman sows crops in it turning it green.<br>
Man ploughs, woman waters; that earth and water mixed together, brings about a harvest of golden paddy.<br>

</i><br><br>

However, Nazrul's poems strongly emphasise the confluence of the roles of both sexes and their equal importance to life. He stunned society with his poem "Barangana" ("Prostitute"), in which he addresses a prostitute as "mother". Nazrul expresses no hesitation in accepting the prostitute as a human being. Reasoning that this person was breast-fed by a noble woman and belonging to the race of "mothers and sisters," he assails society's notions of prostitutes as impure and ignoble persons. However, Nazrul's emphasis does not exceed the basic roles of women in society. Nazrul explores a woman's feelings in one of his most popular songs, "Mour Ghumghore Key Elay Monohour" ("Who is the beauty that traverses my dream?"), at her separation from her husband. While vivid in his account of the woman's torment, Nazrul has been criticized in modern times for not exploring the possibility that a woman's life may reach beyond wifely duties. Nazrul elucidates the feelings of an "ideal woman," devoted to her husband and explores the imagination of men in their idealization of woman. Nazrul's songs are commonly called as Nazrul geeti, which is still practiced as one of the most popular variety of songs in Bengali, like Rabindra Sangeet (songs of Rabindranath Tagore).
<br><br><br><br>

<h3 style="color:#641016">Exploring Religion:</h3>

Nazrul's mother died in 1928, and his second son Bulbul died of smallpox the following year. His first son, Krishna Mohammad had died prematurely. His wife gave birth to two more sons — Savyasachi in 1928 and Aniruddha in 1931 — but Nazrul remained shaken and aggrieved for a long time. His works changed significantly from rebellious expositions of society to deeper examination of religious themes. His works in these years led Islamic devotional songs into the mainstream of Bengali folk music, exploring the Islamic practices of namaz (prayer), roza (fasting), hajj (pilgrimage) and zakat (charity). This was regarded by his contemporaries as a significant achievement as Bengali Muslims had been strongly averse to devotional music. Nazrul's creativity diversified as he explored Hindu devotional music by composing bhajans and kirtans, often merging Islamic and Hindu values. Nazrul's poetry and songs explored the philosophy of Islam and Hinduism.
<br><br>
Let people of all countries and all times come together. At one great union of humanity. Let them listen to the flute music of one great unity. Should a single person be hurt, all hearts should feel it equally. If one person is insulted; it is a shame to all mankind, an insult to all! Today is the grand uprising of the agony of universal man. <br><br>
Nazrul is considered to have been one of the most brilliant exponents of Shaktism, a form of Hinduism widely practised in Bengal and Assam. Nazrul's poetry imbibed the passion and creativity of Shakti, which is identified as the Brahman, the personification of primordial energy. He wrote and composed many bhajans, shyamasangeet, agamanis and kirtans. He also composed large number of songs on invocation to Lord Shiva, Goddesses Lakshmi and Saraswati and on the theme of love of Radha and Krishna. For many contemporary critics, Nazrul's works also reflect the universalism of the teachings of sages Kabir and Guru Nanak as well as the syncretism of Mughal emperor Akbar's Din-i-Illahi school.<br><br>

Open your heart — within you dwell all the religions. All the prophets — your heart. Is the universal temple…. Why do you search for God in vain. Within the skeletons of dead scriptures. When he smilingly resides in your immortal heart? I'm not lying to you, my friend. Before this heart, all nobility surrenders.
<br><br>

Nazrul assailed fanaticism in religion, denouncing it as evil and inherently irreligious. He devoted many works to expound upon the principle of human equality, exploring the Qur'an and the life of Islam's prophet Muhammad. Nazrul has been compared to W.B. Yeats for being the first Muslim poet to create imagery and symbolism of Muslim historical figures such as Qasim, Ali, Umar, Kamal Pasha, Anwar Pasha and the prophet Muhammad. His vigorous assault on extremism and mistreatment of women provoked condemnation from religious Muslims, many of whom denounced him as a kaffir (heretic).
<br><br><br><br>
<h3 style="color:#641016">Later life and Illness :</h3>

In 1933, Nazrul published a collection of essays titled "Modern World Literature," in which he analyzed different styles and themes of literature. Nazrul identified two main literary trends — the first demonstrates passionate devotion to Earth with the exploration of the home environment of human beings; the second attempts to rise above and out of Earth to explore and reach the heavens. Between 1928 and 1935 he published 10 volumes of songs containing over 800 songs of which more than 600 were based on classical ragas. Almost 100 were folk tunes after kirtans and some 30 were patriotic songs. From the time of his return to Kolkata until he fell ill in 1941, Nazrul composed more than 2600 songs, many of which have been lost. His songs based on baul, jhumur, Santhali folksongs, jhanpan or the folk songs of snake charmers, bhatiali and bhaoaia consist of tunes of folk-songs on the one hand and a refined lyric with poetic beauty on the other. He also wrote poetry, songs and stories for children, seeking to inspire the thirst for knowledge, the spirit of freedom and independent thinking.

Nazrul's success soon brought him into Indian theater and the nascent film industry. The first picture for which he worked was based on Girish Chandra Ghosh's story "Bhakta Dhruva" in 1934. Nazrul acted in the role of Narada and directed the film. He also composed songs for it, directed the music and served as a playback singer. The film Vidyapati (Master of Knowledge) was produced based on his recorded play in 1936, and Nazrul served as the music director for the film adaptation of Tagore's novel Gora. Nazrul wrote songs and directed music for Sachin Sengupta's bioepic play Siraj-ud-Daula. In 1939, Nazrul began working for Calcutta Radio, supervising the production and broadcasting of the station's musical programmes. He produced critical and analytic documentaries on music, such as Haramoni and Navaraga-malika. Nazrul also wrote a large variety of songs inspired by the raga Bhairav. In these final years of activity, Nazrul worked intensely and his fame spread across India. While enjoying commercial success, Nazrul sought to preserve his artistic integrity by condemning the adaptation of his songs to music composed by others and insisting on the use of tunes he composed himself.




Nazrul's wife Pramila Devi fell seriously ill in 1939 and was paralyzed from the waist down. To provide for his wife's medical treatment, he sold his property as well as copyrights and royalties he received for his works.[8] He returned to journalism in 1941 by working as chief editor for the daily newspaper Nabayug ("New Age"), founded by the eminent Bengali politician A. K. Fazlul Huq.[12] Nazrul also was shaken by the death of Rabindranath Tagore on August 8, 1941. He spontaneously composed two poems in Tagore's memory, one of which, "Rabihara" (loss of Rabi or without Rabi) was broadcast on the All India Radio. Within months, Nazrul himself fell seriously ill and gradually began losing his power of speech. His behaviour became erratic, and spending recklessly, he fell into financial difficulties. Embittered by the sudden loss of his active life, Nazrul wrote in a letter to his friend Zulfikar Haider on July 17, 1942:
<br><br>
<i>
…I am bed-ridden due to blood pressure. I am writing with great difficulty. My home is filled with worries — illness, debt, creditors; day and night I am struggling…. My nerves are shattered. For the last six months, I used to visit Mr. Haque daily and spend 5-6 hours like a beggar…. I am unable to have quality medical help…. This might be my last letter to you. With only great difficulty, I can utter a few words. I am in pain almost all over my body. I might get money like the poet Ferdowsi on the day of the janajar namaz (funeral prayer). However, I have asked my relatives to refuse that money….<br> Yours, Nazrul.
<br><br>
</i>
In spite of her own predicament his wife constantly cared for her husband. However, Nazrul's health seriously deteriorated and he grew increasingly depressed. He underwent medical treatment under homeopathy as well as Ayurveda, but little progress was achieved before mental dysfunction intensified and he was admitted to a mental asylum in 1942. Spending four months there without making progress, Nazrul and his family began living a silent life in India. In 1952, he was transferred to a mental hospital in Ranchi. With the efforts of a large group of admirers who called themselves the "Nazrul Treatment Society" as well as prominent supporters such as the Indian politician Syama Prasad Mookerjee, the poet travelled to London for treatment. Eminent physicians in London and later Vienna stated that he had received poor medical care. Dr. Hans Hoff, a leading neurosurgeon in Vienna, diagnosed Nazrul as suffering from Pick's Disease. His condition judged to be incurable, Nazrul returned to India in December 1953.
<br><br>
On June 30, 1962 his wife Pramila died. Nazrul remained in intensive medical care. In 1972, the newly independent nation of Bangladesh obtained permission from the Government of India to bring Nazrul to live in Dhaka and accorded him honorary citizenship. Despite receiving treatment and attention, Nazrul's physical and mental health did not improve. In 1974, his youngest son, Kazi Aniruddha, an eminent guitarist died, and Nazrul soon succumbed to his long-standing ailments on August 29, 1976. In accordance with a wish he had expressed in one of his poems, he was buried beside a mosque on the campus of the University of Dhaka. Tens of thousands of people attended his funeral. Bangladesh observed two days of national mourning and the Indian Parliament observed a minute of silence in his honour. His last surviving son Sabhyasachi died in 1979.<br><br><br><br>
<h3 style="color:#641016">Criticism and legacy :</h3>

While his career was active, Nazrul received intense criticism from religious Muslims for his assimilation of Hindu philosophy and culture with Islam in his works and for openly denouncing many Islamic teachings.[8] Although a Muslim, he named his sons with both Hindu and Muslim names -Krishna Mohammad, Arindam Khaled(bulbul), Kazi Sazbyasachi and Kazi Aniruddha. His rebellious nature has also earned him the adage of the "anarchist poet,” as he criticized the main political parties and ideologies of the day. Nazrul is hailed for his sincere conviction in the liberation of women. His poems explored the independence of a woman's mind and the ability to perform diverse roles in society. His vision of gender equality was powerfully expressed in his poem "Woman."
<br><br>
Nazrul's poetry is characterized by an abundant use of rhetorical devices, which he employs to convey conviction and sensuousness. He often wrote without caring for organization or polishing his work. His works have been criticized often for egotism, but his admirers counter that they carry self-confidence. They cite his ability to defy God yet maintain an inner, humble devotion. Nazrul's poetry is regarded as rugged but unique in comparison to his contemporary Rabindranath Tagore's sophisticated style. Nazrul's use of Persian vocabulary was controversial but it widened the scope of his work. Nazrul's works for children have won acclaim for his use of rich language, imagination, enthusiasm and an ability to fascinate young readers. Kazi Nazrul Islam is acknowledged as one of the greatest Bengali poets of all time. He pioneered new styles and expressed radical ideas and emotions in a large collection of works. Scholars credit him for spearheading a cultural renaissance in the Muslim community of Bengal, "liberating" poetry and literature in Bengali from its medieval mould. Nazrul was awarded the Jagattarini Gold Medal in 1945 — the highest honor for work in Bengali literature by the University of Calcutta — and awarded the Padma Bhushan, one of India's highest civilian honors in 1960. The Government of Bangladesh conferred upon him the status of "national poet." He was awarded the "Ekushe Padak" by the Government of Bangladesh. He was awarded Honorary D.Litt. by the University of Dhaka. Many centers of learning and culture in India and Bangladesh have been founded and dedicated to his memory. The Nazrul Endowment is one of several scholarly institutions established to preserve and expound upon his thoughts and philosophy, as well as the preservation and analysis of the large and diverse collection of his works. The Bangladesh Nazrul Sena is a large public organization working for the education of children throughout the country. Nazrul's numerous works remain widely popular with the public of India and Bangladesh.
</div>
  </div>
  <div class="tab-pane fade" id="nav-novel" role="tabpanel" aria-labelledby="nav-novel-tab">

<?php

if(isset($_POST['search']))
{
    $valueToSearch = $_POST['valueToSearch'];
    // search in all table columns
    // using concat mysql function
    $query = "SELECT * FROM `kazinovels` WHERE CONCAT( `name`, `writer`, `category`,`description`,`link`) LIKE '%".$valueToSearch."%'";
    $search_result = filterTable($query);
    
}
 else {
    $query = "SELECT * FROM `kazinovels`";
    $search_result = filterTable($query);
}

// function to connect and execute the query
function filterTable($query)
{
    $connect = mysqli_connect("localhost", "root", "", "blog");
    $filter_Result = mysqli_query($connect, $query);
    return $filter_Result;
}

?>

 <form action="Nazrulprofile.php" method="post"> 
            <br><br>
             <table style="border: 2px solid #641016;" class="text-white">
                <tr class="my-4">
                   
                    <th>Name</th>
                    <th>Writer</th>
                    <th>Category</th>
                    <th class="corner wideRow">Description</th>
                    <th>Link</th>
                </tr>

      <!-- populate table from mysql database -->
                <?php while($row = mysqli_fetch_array($search_result)):?>
                <tr>
                    
                    <td style="font-weight: bolder"><?php echo $row['name'];?></td>
                    <td><?php echo $row['writer'];?></td>
                    <td><?php echo $row['category'];?></td>
                     <td><?php echo $row['description'];?></td>
                      <td><?php echo $row['link'];?></td>
                </tr>
                <?php endwhile;?>
            </table>
        </form>
  </div>


  <div class="tab-pane fade" id="nav-poetry" role="tabpanel" aria-labelledby="nav-poetry-tab">
<?php

if(isset($_POST['search']))
{
    $valueToSearch = $_POST['valueToSearch'];
    // search in all table columns
    // using concat mysql function
    $query = "SELECT * FROM `nazrulpoetry` WHERE CONCAT( `name`, `writer`, `category`,`description`,`link`) LIKE '%".$valueToSearch."%'";
    $search_result = filterTable($query);
    
}
 else {
    $query = "SELECT * FROM `nazrulpoetry`";
    $search_result = filterTable($query);
}

// function to connect and execute the query
function filterTable2($query)
{
    $connect = mysqli_connect("localhost", "root", "", "blog");
    $filter_Result = mysqli_query($connect, $query);
    return $filter_Result;
}

?>

 <form action="Nazrulprofile.php" method="post"> 
            <br><br>
             <table style="border: 2px solid #641016;" class="text-white">
                <tr class="my-4">
                   
                    <th>Name</th>
                    <th>Writer</th>
                    <th>Category</th>
                       <th class="corner wideRow" >Description</th>
                    <th>Link</th>
                </tr>

      <!-- populate table from mysql database -->
                <?php while($row = mysqli_fetch_array($search_result)):?>
                <tr>
                    
                    <td style="font-weight: bolder"><?php echo $row['name'];?></td>
                    <td><?php echo $row['writer'];?></td>
                    <td><?php echo $row['category'];?></td>
                     <td><?php echo $row['description'];?></td>
                      <td><?php echo $row['link'];?></td>
                </tr>
                <?php endwhile;?>
            </table>
        </form>
  </div>


  
 <div class="tab-pane fade" id="nav-essay" role="tabpanel" aria-labelledby="nav-essay-tab">

<?php

if(isset($_POST['search']))
{
    $valueToSearch = $_POST['valueToSearch'];
    // search in all table columns
    // using concat mysql function
    $query = "SELECT * FROM `kaziessay` WHERE CONCAT( `name`, `writer`, `category`,`description`,`link`) LIKE '%".$valueToSearch."%'";
    $search_result = filterTable($query);
    
}
 else {
    $query = "SELECT * FROM `kaziessay`";
    $search_result = filterTable($query);
}

// function to connect and execute the query
function filterTable4($query)
{
    $connect = mysqli_connect("localhost", "root", "", "blog");
    $filter_Result = mysqli_query($connect, $query);
    return $filter_Result;
}

?>

 <form action="Nazrulprofile.php" method="post"> 
           <br><br>
             <table style="border: 2px solid #641016;" class="text-white">
                <tr class="my-4">
                   
                    <th>Name</th>
                    <th>Writer</th>
                    <th>Category</th>
                    <th class="corner wideRow">Description</th>
                    <th>Link</th>
                </tr>

      <!-- populate table from mysql database -->
                <?php while($row = mysqli_fetch_array($search_result)):?>
                <tr>
                    
                    <td style="font-weight: bolder"><?php echo $row['name'];?></td>
                    <td><?php echo $row['writer'];?></td>
                    <td><?php echo $row['category'];?></td>
                     <td><?php echo $row['description'];?></td>
                      <td><?php echo $row['link'];?></td>
                </tr>
                <?php endwhile;?>
            </table>
        </form>
  </div>

   <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/4.5.0/js/bootstrap.bundle.min.js"></script>
  
</main>
</div>
</body>