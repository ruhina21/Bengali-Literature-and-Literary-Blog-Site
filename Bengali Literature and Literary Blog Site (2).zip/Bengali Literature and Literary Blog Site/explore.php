	<!DOCTYPE html>
	<html>
	<head>
		<title>মালতী</title>
		 <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
	    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.1/css/all.min.css">
	    <link rel="stylesheet" href="/css/bootstrap-grid.min.css">
	    <link rel="stylesheet" href="explr.css">
	    <link rel="preconnect" href="https://fonts.gstatic.com">
	      <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.1/css/all.min.css">
	    <link href="https://fonts.googleapis.com/css2?family=Big+Shoulders+Stencil+Text:wght@700&display=swap" rel="stylesheet">
	    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.1.3/css/bootstrap.min.css" integrity="sha384-MCw98/SFnGE8fJT3GXwEOngsV7Zt27NXFoaoApmYm81iuXoPkFOJwJ8ERdknLPMO" crossorigin="anonymous">
      <link rel="preconnect" href="https://fonts.gstatic.com">
<link href="https://fonts.googleapis.com/css2?family=Abril+Fatface&display=swap" rel="stylesheet">
<style>
  .nav-item{
  font-family: 'Abril Fatface', cursive;
}
</style>
	</head>
	<body style="background-color:black" >
	<div class="container">
		<header class="mx-0 " >
	    <nav class="navbar navbar-expand-md navbar-dark fixed-top">
	  <a class="navbar-brand" href="http://localhost/project/projecting.php">
	<img src="6bfd6d9ed685fc2b0af4bed3f790c0ae.jpg" style="width:100px" class="rounded-circle"alt="Maloti">
      </a>
      <div class="collapse navbar-collapse" id="navbarNav">

    <ul class="navbar-nav ">

      <li class="nav-item active font-weight-bolder">
       <button class="btn btn-lg  mr-3 " style="font-weight: bolder ;background-color: yellow"> <a class="nav-link" style="color: yellow;background-color: #641016" href="#বাঙালি">AUTHOR LIST<span class="sr-only">(current)</span></a></button>
      </li>
      <li class="nav-item ">
       <button class="btn btn-lg bg-warning mr-3 " > <a class="nav-link" style="color: #641016" href="http://localhost/project/Booklist.php">BOOK LIST</a></button>
      </li>
      <li class="nav-item">
        <button class="btn btn-lg bg-warning " ><a class="nav-link" href="http://localhost/project/add_rate.php" style="color: #641016">BLOG SECTION</a></button>
      </li>

     
    </ul>
  </div>
	
	</nav>
	 </header>
<main>
	<br><br><br><br><br><br><br><br>
	<section id="বাঙালি">
		 <div class="section-title py-3">
        <h1 class="text-center" style="text:#c30c02">AUTHOR LIST</h1>
        </div>
        <br><br>
        <div class="row">
        	<div class="col-lg-4">
	<div class="card" style="width: 18rem;">
  <img src="tagore.jpg" class="card-img-top" alt="..." style= "height: 350px" alt>
  <div class="card-body">
    <h5 class="card-title">Rabindranath Tagore</h5>
    <p class="card-text">Rabindranath Tagore was born as Robindronath Thakur ..............</p>
    <a href="http://localhost/project/rabindraprofile.php" class="btn btn-warning"><b>GO FOR BOOKS</b></a>
  </div>
</div>
</div>

<div class="col-lg-4">
	<div class="card" style="width: 18rem;">
  <img src="kazi.jpg" class="card-img-top" style="height: 350px" alt="...">
  <div class="card-body">
    <h5 class="card-title">Kazi Nazrul Islam</h5>
    <p class="card-text ">Kazi Nazrul Islam was born in the village of Churulia in the ..............</p>
    <a href="http://localhost/project/Nazrulprofile.php" class="btn btn-warning"><b>GO FOR BOOKS</b></a>
  </div>
</div>
</div>

  
<div class="col-lg-4">
  <div class="card" style="width: 18rem;">
  <img src="sunil.jpg"  style="height: 350px" class="card-img-top" alt="...">
  <div class="card-body">
    <h5 class="card-title">Sunil Gangopadhyay</h5>
    <p class="card-text">Sunil Gangopadhyay was born in Faridpur, ............</p>
    <a href="http://localhost/project/sunilprofile.php" class="btn btn-warning"><b>GO FOR BOOKS</b></a>
  </div>
</div>
</div>



</div>
<div class="row mt-4">
        	<div class="col-lg-4">
	<div class="card" style="width: 18rem;">
  <img src="manik.jpg" style="height: 350px" class="card-img-top" alt="...">
  <div class="card-body">
    <h5 class="card-title">Manik Bandopaddhyay</h5>
    <p class="card-text">Born in a small town called Dumka, in Santal   ..............</p>
    <a href="http://localhost/project/manikprofile.php" class="btn btn-warning"><b>GO FOR BOOKS</b></a>
  </div>
</div>
</div>

<div class="col-lg-4">
	<div class="card" style="width: 18rem;">
  <img src="sharat.jpg" style="height: 350px"  class="card-img-top" alt="...">
  <div class="card-body">
    <h5 class="card-title">Sharat Chandra Chattopadhyay</h5>
    <p class="card-text">Sarat Chandra Chattopadhyay was born on ..............</p>
    <a href="http://localhost/project/sharat.php" class="btn btn-warning"><b>GO FOR BOOKS</b></a>
  </div>
</div>
</div>


<div class="col-lg-4">
  <div class="card" style="width: 18rem;">
  <img src="bankim.jpg" style="height: 350px" class="card-img-top" alt="...">
  <div class="card-body">
    <h5 class="card-title">Bankim Chandra Chattopadhyay</h5>
    <p class="card-text">Bankim Chandra Chattopadhyay was born in 1838 in ..............</p>
    <a href="http://localhost/project/bankim.php" class="btn btn-warning"><b>GO FOR BOOKS</b></a>
  </div>
</div>
</div>




</div>


<div class="row mt-4">
        	<div class="col-lg-4">
	<div class="card" style="width: 18rem;">
  <img src="samaresh.jpg" style="height: 350px" class="card-img-top" alt="...">
  <div class="card-body">
    <h5 class="card-title">Samaresh Majumdar</h5>
    <p class="card-text">Shamaresh Mazumdar spent his childhood years in the ..............</p>
    <a href="http://localhost/project/samaresh.php" class="btn btn-warning"><b>GO FOR BOOKS</b></a>
  </div>
</div>
</div>

<div class="col-lg-4">
	<div class="card" style="width: 18rem;">
  <img src= "zahir2.jpg" style="height: 350px"  class="card-img-top" alt="...">
  <div class="card-body">
    <h5 class="card-title">Zahir Raihan</h5>
    <p class="card-text">Zahir Raihan(1935-1971) filmmaker and writer, born ..............</p>
    <a href="http://localhost/project/zahir.php" class="btn btn-warning"><b>GO FOR BOOKS</b></a>
  </div>
</div>
</div>

<div class="col-lg-4">
	<div class="card" style="width: 18rem;">
  <img src="humayun.jpg" style="height: 350px" class="card-img-top" alt="...">
  <div class="card-body">
    <h5 class="card-title">Humayun Ahmed</h5>
    <p class="card-text">Ahmed was born on 13 November 1948 in Kutubpur village ..............</p>
    <a href="http://localhost/project/humayun.php" class="btn btn-warning"><b>GO FOR BOOKS</b></a>
  </div>
</div>
</div>


</div>
	</section>

<br><br><br>




</main>
	</div>

	<script src="https://code.jquery.com/jquery-3.5.1.slim.min.js" integrity="sha384-DfXdz2htPH0lsSSs5nCTpuj/zy4C+OGpamoFVy38MVBnE+IbbVYUew+OrCXaRkfj" crossorigin="anonymous"></script>
            <script src="https://cdn.jsdelivr.net/npm/bootstrap@4.5.3/dist/js/bootstrap.bundle.min.js" ntegrity="sha384-ho+j7jyWK8fNQe+A12Hb8AhRq26LrZ/JpcUGGOn+Y7RsweNrtN/tE3MoK7ZeZDyx" crossorigin="anonymous"></script>
            <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js" integrity="sha384-DfXdz2htPH0lsSSs5nCTpuj/zy4C+OGpamoFVy38MVBnE+IbbVYUew+OrCXaRkfj" crossorigin="anonymous"></script>
            <script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.1/dist/umd/popper.min.js" integrity="sha384-9/reFTGAW83EW2RDu2S0VKaIzap3H66lZH81PoYlFhbGU+6BZp6G7niu735Sk7lN" crossorigin="anonymous"></script>
            <script src="https://cdn.jsdelivr.net/npm/bootstrap@4.5.3/dist/js/bootstrap.min.js" integrity="sha384-w1Q4orYjBQndcko6MimVbzY0tgp4pWB4lZ7lr30WKz0vr/aWKhXdBNmNb5D92v7s" crossorigin="anonymous"></script>
	</body>
	</html>