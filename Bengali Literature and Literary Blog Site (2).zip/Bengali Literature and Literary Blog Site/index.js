
console.log(Number("    24"));
