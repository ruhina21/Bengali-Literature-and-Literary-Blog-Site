
<!DOCTYPE html>
  <html>
  <head>
    <title>Bankim Chandra Chattopaddhyay</title>
     <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
      <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.1/css/all.min.css">
      <link rel="stylesheet" href="/css/bootstrap-grid.min.css">
      <link rel="stylesheet" href="explr.css">
      <link rel="preconnect" href="https://fonts.gstatic.com">
        <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.1/css/all.min.css">
      <link href="https://fonts.googleapis.com/css2?family=Big+Shoulders+Stencil+Text:wght@700&display=swap" rel="stylesheet">
      <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.1.3/css/bootstrap.min.css" integrity="sha384-MCw98/SFnGE8fJT3GXwEOngsV7Zt27NXFoaoApmYm81iuXoPkFOJwJ8ERdknLPMO" crossorigin="anonymous">
       <link rel="stylesheet" href="table.css">
      <link rel="preconnect" href="https://fonts.gstatic.com">
<link href="https://fonts.googleapis.com/css2?family=Abril+Fatface&display=swap" rel="stylesheet">
<style>
  .nav-item{
    color: #641016;
    font-weight: bold;
font-family: 'Abril Fatface', cursive;
  }
  .nav-item:hover{
   color : yellow; 
   transform:scale(1.1);
  }
p{
  color: #ffffff;
}
i{
  color:grey;
  width: 50%;
}
h3{
 
  font-family: 'Abril Fatface', cursive;

}
table,tr,th,td
            {
                border: 2px solid #641016;

            }
            table td.wideRow, table th.wideRow {
  width: 500px;
}
th{

  color:yellow;
}
</style>
  </head>
  <body style="background-color:black" >
  <div class="container">
    <header class="mx-0 " >
      <nav class="navbar navbar-expand-md navbar-dark fixed-top">
    <a class="navbar-brand" href="http://localhost/project/projecting.php">
  <img src="6bfd6d9ed685fc2b0af4bed3f790c0ae.jpg" style="width:100px" class="rounded-circle"alt="Maloti">
      </a>
      <div class="collapse navbar-collapse" id="navbarNav">

    <ul class="navbar-nav ">

      <li class="nav-item active font-weight-bolder">
       <button class="btn btn-lg  mr-3 " style="font-weight: bolder ;background-color: yellow"> <a class="nav-link" style="color: yellow;background-color: #641016" href="http://localhost/project/explore.php">AUTHOR LIST<span class="sr-only">(current)</span></a></button>
     </li>
     <li class="nav-item ">
       <button class="btn btn-lg bg-warning mr-3 " > <a class="nav-link" style="color: #641016" href="http://localhost/project/Booklist.php">BOOK LIST</a></button>
      </li>
      <li class="nav-item">
        <button class="btn btn-lg bg-warning " ><a class="nav-link" href="http://localhost/project/upload.php" style="color: #641016">BLOG SECTION</a></button>
      </li>

     
    </ul>
  </div>
  <img src="bankim.jpg" class="rounded-circle " style="height: 70px" >
</nav>
</header>

<main>
  <br> <br> <br> <br><br><br><br>
   <h1 style=" color: #641016; font-family: 'Big Shoulders Stencil Text', cursive;" class="text-center">Bankim Chandra Chattopaddhyay</h1>
  <nav>
  <div class="nav nav-tabs" id="nav-tab" role="tablist">
    <a class="nav-item nav-link active " id="nav-profile-tab" data-toggle="tab" href="#nav-profile" role="tab" aria-controls="nav-profile" aria-selected="true">Profile</a>
    <a class="nav-item nav-link" id="nav-novel-tab" data-toggle="tab" href="#nav-novel" role="tab" aria-controls="nav-novel" aria-selected="false">Novels</a>

  </div>
</nav>
<div class="tab-content" id="nav-tabContent">
  <div class="tab-pane fade show active " id="nav-profile" role="tabpanel" aria-labelledby="nav-profile-tab"><img class="mr-4 mb-4" style="float: left ;width:400px;height: 400px" src="bankim.jpg"><br>
   
<p class="mx-auto" style="color:white">
 <br> 

Date of Birth:  27 June 1838 
<br>
Place of Birth: Kanthalpara,Bengal
<br><br>
Father: Yadav Chandra Chattopaddhyay
<br>
Mother: Durga Devi
<br><br>
Nationality: Indian
<br><br>
Spouse: Rajlakshmi Devi
<br><br>
Date of Death: April 8,1894
<br>
Place Of Death: Kolkata, Bengal
<br>
<br>
<br><br><br>
<div class="text-white">
<h3 style="color:#641016">Early life :</h3>
 Bankim Chandra Chattopadhyay was born in 1838 in Kanthalpara, a small village of West Bengal, into an orthodox Brahmin family to Yadav Chandra Chattopadhyay and Durgadebi. His father was a notable Deputy Collector of Midnapur.<br><br>
Bankim received the best of education from the Hooghly Mohsin College, which was founded by the famous humanitarian Muhammad Mohsin. He went on for his higher education at the Presidency College and graduated with a Bachelor’s Degree in Law in 1857.
<br><br><br>

<h3 style="color:#641016">Literary Career :</h3>
Bankim, after completing his studies in Law, was appointed as Deputy Collector just like his father. He served the British for almost thirty two years and became the Deputy Magistrate eventually, and retired from the government service in 1891.<br><br>
He was fond of writing and began his literary journey as a verse writer, just like his idol Ishwarchandra Gupta. It was later when he discovered his potential for writing properly that he turned to fiction. His first ever writing was a novella that he wrote for a competition. As he did not win the competition and the novella was never published.<br><br>
His first published work was a novella in English language called ‘Rajmohan’s Wife’. But since it was written in English, it failed to achieve much appreciation and he realized that if he wanted to write then he had to write in Bengali.<br><br>
This led to the publication of his first Bengali fiction called ‘Durgeshnondini’ in 1865. This was a Bengali romance novel. This was followed by his first big publication—‘Kapalkundala’. The novel established him as a writer.<br><br>
In 1869, Mrinalini came out, which was Bankim’s bold attempt at writing a novel that has its story set in a historical context. Later, he started publishing his monthly literary magazine called Bangadarshan. The magazine went out of circulation within 4 years.
Chandrasekhar was published in 1877. The novel had a different style than Bankim’s other works. In the same year, he also published ‘Rajani’ which is said to be autobiographical.<br><br>
Bankim wrote ‘Anandamath (The Abbey of Bliss)’ in 1882 which was a political novel. Its plot was in the theme of Hindu nationalism against the British rule. The book was the source of the song Vande Mataram, which later became the national song of India.<br><br>
Others works that Bankim published in his lifetime were: ‘ Lok Rahasya (1874)’, ‘Bichitra Prabandha (1876)’, ‘Devi Chaudhurani (1884)’, ‘Kamalakanta (1885)’, ‘Sitaram (1887)’, ‘Muchiram Gurer Jivancharita’, ‘Krishna Charitra (1886)’, ‘Dharmatattva (1886)’, etc.<br><br><br>
<h3 style="color:#641016">Major Works :</h3>

Although Bankim is known for all of his novels and essays but he is known for ‘Anandamath (The Abbey of Bliss) the most as it was from this novel that Rabindranath Tagore took the song ‘Vande Mataram’ and converted into the national song of India.<br><br><br>

<h3 style="color:#641016">Personal Life :</h3>

Bankim was married when he was just eleven years old. His wife was only five years old then. He was twenty two when his wife died, which is why he got married again. His second wife was Rajlakshmi Devi. They had three daughters together.
<br><br>
Bankim studied Sanskrit as a child and was very interested in the subject.
This famous poet and writer was almost always in conflict with the British rule during his government service days.
<br><br><br>

<h3 style="color:#641016">Death :</h3>
He passed away on 8th April 1894.It was a normal death.


</div>
  </div>
  <div class="tab-pane fade" id="nav-novel" role="tabpanel" aria-labelledby="nav-novel-tab">

<?php

if(isset($_POST['search']))
{
    $valueToSearch = $_POST['valueToSearch'];
    // search in all table columns
    // using concat mysql function
    $query = "SELECT * FROM `bankimnovel` WHERE CONCAT( `name`, `writer`, `category`,`description`,`link`) LIKE '%".$valueToSearch."%'";
    $search_result = filterTable($query);
    
}
 else {
    $query = "SELECT * FROM `bankimnovel`";
    $search_result = filterTable($query);
}

// function to connect and execute the query
function filterTable($query)
{
    $connect = mysqli_connect("localhost", "root", "", "blog");
    $filter_Result = mysqli_query($connect, $query);
    return $filter_Result;
}

?>

 <form action="bankim.php" method="post"> 
            <br><br>
             <table style="border: 2px solid #641016;" class="text-white text-center">
                <tr class="mx-4 ml-4 my-4">
                   
                    <th class="mr-4 ml-4 my-4">Name</th>
                    <th class="mr-4 ml-4 my-4">Writer</th>
                    <th class="mr-4 ml-4 my-4">Category</th>
                    <th class="corner wideRow">Description</th>
                    <th class="mr-4 ml-4 my-4">Link</th>
                </tr>

      <!-- populate table from mysql database -->
                <?php while($row = mysqli_fetch_array($search_result)):?>
                <tr class="mr-4 ml-4 my-4">
                    
                    <td style="font-weight: bolder" class="mr-4 ml-4 my-4"><?php echo $row['name'];?></td>
                    <td class="mr-4 ml-4 my-4"><?php echo $row['writer'];?></td>
                    <td class="mr-4 ml-4 my-4"><?php echo $row['category'];?></td>
                     <td class="mr-4 ml-4 my-4"><?php echo $row['description'];?></td>
                      <td class="mr-4 ml-4 my-4"><?php echo $row['link'];?></td>
                </tr>
                <?php endwhile;?>
            </table>
        </form>
  </div>




   <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/4.5.0/js/bootstrap.bundle.min.js"></script>
  
</main>
</div>
</body>