
<!DOCTYPE html>
  <html>
  <head>
    <title>Zahir Raihan</title>
     <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
       <link rel="stylesheet" href="table.css">
      <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.1/css/all.min.css">
      <link rel="stylesheet" href="/css/bootstrap-grid.min.css">
      <link rel="stylesheet" href="explr.css">
      <link rel="preconnect" href="https://fonts.gstatic.com">
        <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.1/css/all.min.css">
      <link href="https://fonts.googleapis.com/css2?family=Big+Shoulders+Stencil+Text:wght@700&display=swap" rel="stylesheet">
      <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.1.3/css/bootstrap.min.css" integrity="sha384-MCw98/SFnGE8fJT3GXwEOngsV7Zt27NXFoaoApmYm81iuXoPkFOJwJ8ERdknLPMO" crossorigin="anonymous">
      <link rel="preconnect" href="https://fonts.gstatic.com">
<link href="https://fonts.googleapis.com/css2?family=Abril+Fatface&display=swap" rel="stylesheet">
<style>
  .nav-item{
    color: #641016;
    font-weight: bold;
font-family: 'Abril Fatface', cursive;
  }
  .nav-item:hover{
   color : yellow; 
   transform:scale(1.1);
  }
p{
  color: #ffffff;
}
i{
  color:grey;
  width: 50%;
}
h3{
 
  font-family: 'Abril Fatface', cursive;

}
table,tr,th,td
            {
                border: 2px solid #641016;

            }
            table td.wideRow, table th.wideRow {
  width: 500px;
}
th{

  color:yellow;
}
</style>
  </head>
  <body style="background-color:black" >
  <div class="container">
    <header class="mx-0 " >
      <nav class="navbar navbar-expand-md navbar-dark fixed-top">
    <a class="navbar-brand" href="http://localhost/project/projecting.php">
  <img src="6bfd6d9ed685fc2b0af4bed3f790c0ae.jpg" style="width:100px" class="rounded-circle"alt="Maloti">
      </a>
      <div class="collapse navbar-collapse" id="navbarNav">

    <ul class="navbar-nav ">

      <li class="nav-item active font-weight-bolder">
       <button class="btn btn-lg  mr-3 " style="font-weight: bolder ;background-color: yellow"> <a class="nav-link" style="color: yellow;background-color: #641016" href="http://localhost/project/explore.php">AUTHOR LIST<span class="sr-only">(current)</span></a></button>
     </li>
     <li class="nav-item ">
       <button class="btn btn-lg bg-warning mr-3 " > <a class="nav-link" style="color: #641016" href="http://localhost/project/Booklist.php">BOOK LIST</a></button>
      </li>
      <li class="nav-item">
        <button class="btn btn-lg bg-warning " ><a class="nav-link" href="http://localhost/project/upload.php" style="color: #641016">BLOG SECTION</a></button>
      </li>

     
    </ul>
  </div>
  <img src="zahir2.jpg" class="rounded-circle " style="height: 70px ;width: 70px" >
</nav>
</header>

<main>
  <br> <br> <br> <br><br><br><br>
   <h1 style=" color: #641016; font-family: 'Big Shoulders Stencil Text', cursive;" class="text-center">Zahir Raihan</h1>
  <nav>
  <div class="nav nav-tabs" id="nav-tab" role="tablist">
    <a class="nav-item nav-link active " id="nav-profile-tab" data-toggle="tab" href="#nav-profile" role="tab" aria-controls="nav-profile" aria-selected="true">Profile</a>
    <a class="nav-item nav-link" id="nav-novel-tab" data-toggle="tab" href="#nav-novel" role="tab" aria-controls="nav-novel" aria-selected="false">Novels</a>

  </div>
</nav>
<div class="tab-content" id="nav-tabContent">
  <div class="tab-pane fade show active " id="nav-profile" role="tabpanel" aria-labelledby="nav-profile-tab"><img class="mr-4 mb-4" style="float: left ;width:350px;height: 400px" src="zahir2.jpg"><br>
   
<p class="mx-auto" style="color:white">
 <br> 

Date of Birth:   19 August 1935 
<br>
Place of Birth: Majupur village, in the then Feni Mahakuma under Noakhali District
<br><br>
Father: Mohammad Habibulla
<br>
Mother: Syeda Sufia Khatun
<br><br>
Nationality: Bangladeshi 
<br><br>
Spouse: Shuchonda
<br><br>
Disappreared: 30 January 1972
<br>
Place of Death: Dhaka
<br>
<br>
<br><br><br>
<div class="text-white">
<h3 style="color:#641016">Early life :</h3>
  Zahir Raihan(1935-1971) filmmaker and writer, born 19 August 1935 in the village Majupur of Feni district. Zahir had his early education in Mitra Institute and later, he studied in Calcutta Alia Madrasah, where his father was a professor. After the Partition of Bengal in 1947, he along with his parents returned back to their own village. Zahir passed the Matriculation in 1950 from Amirabad High School and was then admitted to Dhaka College, from where he passed ISc Examinations. He obtained BA (Hon) in Bangla from the University of Dhaka.
<br><br><br>
<h3 style="color:#641016">Political Works :</h3>
In his early years, Zahir was attracted by the communist movement. When Communist Party was banned and the leaders of the party went underground, he worked as a courier to carry letters and messages for them from one place to another. He got the name Raihan from underground leaders and thus his original name Zahirullah was changed to Zahir Raihan. He took an active part in the language movement. He was one of the first 10 students to go out in a procession on 21 February 1952 despite there was a ban on such activities. He and many others were arrested and then taken to prison.  
<br><br><br>
<h3 style="color:#641016">Literary Career :</h3>
Among his novels, Hajar Bochor Dhore is his magnum opus, in which he beautifully portrayed the lives of our rural people. Shesh Bikeler Meye and Borof Gola Nodi are novels in which he intricately told stories about the lives of average people. Arek Falgun, based on the Language Movement, is an exemplary piece of writing which is important to the history of the movement itself.<br><br><br>
<h3 style="color:#641016">Film Career :</h3>
In 1952, Zahir went to Calcutta to learn photography and was admitted to Pramatesh Burua Memorial Photography School. He entered the film world in 1956. Kakhono Asheni, the first film directed by him, was released in 1961. Then came, one after another, his other films Kajal, Kancher Deyal, Behula, Jiban Theke Neya, Anwara, Sangam and Bahana. Jiban Theke Neya depicted the autocratic rule of Pakistan and inspired the people to protest against the Pakistani rulers. He started making an English film Let There Be Light, which he could not finish because of the break out of the war of liberation. After 25 March 1971, he went to Calcutta and produced a documentary film Stop Genocide highlighting the massacre done by the Pakistani Army. This film created a sensation all over the world.<br><br><br>


<h3 style="color:#641016">Awards And Achievements :</h3>
Zahir was honoured with the Adamjee Literature Award for his novel Hajar Bachhar Dhare and the Bangla Academy Award in 1972.<br><br><br>
<h3 style="color:#641016">Death :</h3>
In December 1971, some unknown miscreants took away Zahir's elder brother shahidullah kaiser, an eminent writer from his residence at the University of Dhaka. Within days, on 30 December 1971, someone informed Zahir about an address, somewhere at Mirpur, where he might find his brother. Accordingly, Zahir left home to get his brother back. He never returned and until today, the day is observed as Zahir's Disappearance Day. [Abu Sayeed Khan]


</div>
  </div>
  <div class="tab-pane fade" id="nav-novel" role="tabpanel" aria-labelledby="nav-novel-tab">

<?php

if(isset($_POST['search']))
{
    $valueToSearch = $_POST['valueToSearch'];
    // search in all table columns
    // using concat mysql function
    $query = "SELECT * FROM `jahir` WHERE CONCAT( `name`, `writer`, `category`,`description`,`link`) LIKE '%".$valueToSearch."%'";
    $search_result = filterTable($query);
    
}
 else {
    $query = "SELECT * FROM `jahir`";
    $search_result = filterTable($query);
}

// function to connect and execute the query
function filterTable($query)
{
    $connect = mysqli_connect("localhost", "root", "", "blog");
    $filter_Result = mysqli_query($connect, $query);
    return $filter_Result;
}

?>

 <form action="zahir.php" method="post"> 
            <br><br>
             <table style="border: 2px solid #641016;" class="text-white text-center">
                <tr class="mx-4 ml-4 my-4">
                   
                    <th class="mr-4 ml-4 my-4">Name</th>
                    <th class="mr-4 ml-4 my-4">Writer</th>
                    <th class="mr-4 ml-4 my-4">Category</th>
                    <th class="corner wideRow">Description</th>
                    <th class="mr-4 ml-4 my-4">Link</th>
                </tr>

      <!-- populate table from mysql database -->
                <?php while($row = mysqli_fetch_array($search_result)):?>
                <tr class="mr-4 ml-4 my-4">
                    
                    <td style="font-weight: bolder" class="mr-4 ml-4 my-4"><?php echo $row['name'];?></td>
                    <td class="mr-4 ml-4 my-4"><?php echo $row['writer'];?></td>
                    <td class="mr-4 ml-4 my-4"><?php echo $row['category'];?></td>
                     <td class="mr-4 ml-4 my-4"><?php echo $row['description'];?></td>
                      <td class="mr-4 ml-4 my-4"><?php echo $row['link'];?></td>
                </tr>
                <?php endwhile;?>
            </table>
        </form>
  </div>




   <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/4.5.0/js/bootstrap.bundle.min.js"></script>
  
</main>
</div>
</body>