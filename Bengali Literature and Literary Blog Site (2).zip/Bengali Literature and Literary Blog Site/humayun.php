
<!DOCTYPE html>
  <html>
  <head>
    <title>Humayun Ahmed</title>
     <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
      <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.1/css/all.min.css">
      <link rel="stylesheet" href="/css/bootstrap-grid.min.css">
      <link rel="stylesheet" href="explr.css">
      <link rel="preconnect" href="https://fonts.gstatic.com">
        <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.1/css/all.min.css">
      <link href="https://fonts.googleapis.com/css2?family=Big+Shoulders+Stencil+Text:wght@700&display=swap" rel="stylesheet">
      <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.1.3/css/bootstrap.min.css" integrity="sha384-MCw98/SFnGE8fJT3GXwEOngsV7Zt27NXFoaoApmYm81iuXoPkFOJwJ8ERdknLPMO" crossorigin="anonymous">
        <link rel="stylesheet" href="table.css">
      <link rel="preconnect" href="https://fonts.gstatic.com">
<link href="https://fonts.googleapis.com/css2?family=Abril+Fatface&display=swap" rel="stylesheet">
<style>
  .nav-item{
    color: #641016;
    font-weight: bold;
font-family: 'Abril Fatface', cursive;
  }
  .nav-item:hover{
   color : yellow; 
   transform:scale(1.1);
  }
p{
  color: #ffffff;
}
i{
  color:grey;
  width: 50%;
}
h3{
 
  font-family: 'Abril Fatface', cursive;

}
table,tr,th,td
            {
                border: 2px solid #641016;

            }
            table td.wideRow, table th.wideRow {
  width: 500px;
}
th{

  color:yellow;
}
</style>
  </head>
  <body style="background-color:black" >
  <div class="container">
    <header class="mx-0 " >
      <nav class="navbar navbar-expand-md navbar-dark fixed-top">
    <a class="navbar-brand" href="http://localhost/project/projecting.php">
  <img src="6bfd6d9ed685fc2b0af4bed3f790c0ae.jpg" style="width:100px" class="rounded-circle"alt="Maloti">
      </a>
      <div class="collapse navbar-collapse" id="navbarNav">

    <ul class="navbar-nav ">

      <li class="nav-item active font-weight-bolder">
       <button class="btn btn-lg  mr-3 " style="font-weight: bolder ;background-color: yellow"> <a class="nav-link" style="color: yellow;background-color: #641016" href="http://localhost/project/explore.php">AUTHOR LIST<span class="sr-only">(current)</span></a></button>
     </li>
     <li class="nav-item ">
       <button class="btn btn-lg bg-warning mr-3 " > <a class="nav-link" style="color: #641016" href="http://localhost/project/Booklist.php">BOOK LIST</a></button>
      </li>
      <li class="nav-item">
        <button class="btn btn-lg bg-warning " ><a class="nav-link" href="http://localhost/project/upload.php" style="color: #641016">BLOG SECTION</a></button>
      </li>

     
    </ul>
  </div>
  <img src="humayun.jpg" class="rounded-circle " style="height: 70px;width: 70px" >
</nav>
</header>

<main>
  <br> <br> <br> <br><br><br><br>
   <h1 style=" color: #641016; font-family: 'Big Shoulders Stencil Text', cursive;" class="text-center">Humayun Ahmed</h1>
  <nav>
  <div class="nav nav-tabs" id="nav-tab" role="tablist">
    <a class="nav-item nav-link active " id="nav-profile-tab" data-toggle="tab" href="#nav-profile" role="tab" aria-controls="nav-profile" aria-selected="true">Profile</a>
    <a class="nav-item nav-link" id="nav-novel-tab" data-toggle="tab" href="#nav-novel" role="tab" aria-controls="nav-novel" aria-selected="false">Novels</a>

    <a class="nav-item nav-link" id="nav-sc-tab" data-toggle="tab" href="#nav-sc" role="tab" aria-controls="nav-sc" aria-selected="false">Science-Fiction</a>

  </div>
</nav>
<div class="tab-content" id="nav-tabContent">
  <div class="tab-pane fade show active " id="nav-profile" role="tabpanel" aria-labelledby="nav-profile-tab"><img class="mr-4 mb-4" style="float: left ;width:350px;height: 400px" src="humayun.jpg"><br>
   
<p class="mx-auto" style="color:white">
 <br> 

Date of Birth:  13 November 1948 
<br>
Place of Birth: Netrokona,Mymensingh
<br><br>
Father: Foyzur Rahman Ahmed
<br>
Mother:  Ayesha Foyez
<br><br>
Title : Himu
<br><br>
Spouse: Meher Afroze Shawon
<br><br>
Date of Death: 19 July 2012
<br>
Place of Death: Mount Elizabeth Hospital, Singapore
<br>
<br>
<br><br><br>
<div class="text-white">
<h3 style="color:#641016">Early life :</h3>
  Ahmed was born on 13 November 1948 in Kutubpur village in the then Netrokona Mahakuma under Mymensingh District, East Bengal, Dominion of Pakistan (now in Kendua Upazila, Netrokona District, Bangladesh).His mother, Ayesha Foyez (née Khatun) (1930–2014), was a homemaker. His father, Foyzur Rahman Ahmed (1921–1971), was a sub-divisional police officer in Pirojpur District and was killed in 1971 during the Bangladesh Liberation War. In 2011, politician Delwar Hossain Sayeedi was put on trial for the killing but was acquitted of the charge in 2013 due to a lack of evidence. Humayun's brother, Muhammad Zafar Iqbal, is a writer and academician. Another brother, Ahsan Habib, is a cartoonist. He had three sisters – Sufia Haider, Momtaz Shahid and Rukhsana Ahmed.

During his childhood, Ahmed lived in Sylhet, Comilla, Chittagong, Bogra, Dinajpur and Panchagarh where his father was on official assignment.
<br><br><br>

<h3 style="color:#641016">Early Career :</h3>
Ahmed studied in Chittagong Collegiate School. He passed the SSC examination from Bogra Zilla School in 1965. He then passed HSC from Dhaka College and earned his bachelor's and master's in chemistry from the University of Dhaka. He joined as a faculty member of the same university. Later he earned his PhD in polymer chemistry from North Dakota State University.
<h3 style="color:#641016">Works :</h3>
Ahmed wrote his debut novel Nondito Noroke (In Blissful Hell) during the 1971 Bangladesh independence war while he was a university student. The novel was published in 1972 by the initiative of writer Ahmed Sofa under Khan Brother's Publishers. From his very first novel, his themes included the aspirations of average middle-class urban families and portrayed quintessential moments of their lives. His second novel was Shonkhonil Karagar.

Ahmed wrote fictional series featuring recurring characters such as Himu (21 novels), Misir Ali (20 novels), Shuvro (6 novels) Other important non-rucurring characters are Baker Bhai, Tuni and more. He wrote several novels based on the Bangladesh Liberation War – Aguner Poroshmoni, matal haowa , Paap, 1971 and Jochona O Jononir Golpo.[24] His also wrote many romantic novels including Srabon Megher Din, Badol Diner Prothom Kodom Phool, Noboni, Krishnopoksho, Aj Dupure Tomar Nimontran, and Tumi Amai Dekechhile Chhutir Nimontrane.
<br><br>
Ahmed wrote autobiographies - Amar Chelebela, Ballpoint, Fountain Pen, Hiji-biji, Hotel Graver Inn, May Flower, Kath Pencil, Lilabotir Mrityu, New York-er Nil Akashe Jhokjhoke Rod and Rong Pencil. His novel Gouripur Junction was translated in nine languages.

besides all, he also wrote some books which is alive in the people's heart such as, Tetul bone jochna, asmanira tin bon,Darkaker shangshar kingba majhe majhe tobo dekha pai, Tomake,opekkha,rupa, ni,irina,Ekti cycle ebong koyekti dahuk pakhi,rumali,ayna ghor,onnodin,bohubrihi,eishob dinratri,badshah namdar,megh boleche jabo jabo,ele bele, brishti bilash,jokhon giyeche dube ponchomir chad,ayomoy,ondhokarer gaan,dighir jole kar chaya go,megher chaya,rupali dip,amar ache jol,achinpur,gouripur jongshon,dui duyari,moddhanno,chayabithi,kichukkhon,brihonnola,nirbashon,nil oporajita,liluya batash,the exorcist and so on<br><br><br>

<h3 style="color:#641016">Television and Films :</h3>
Ahmed's first television drama was Prothom Prohor (1983), directed by Nawazish Ali Khan. His first drama serial was Ei Shob Din Ratri (1985). This was followed by the comedy series Bohubrihi (1988), the historical drama series Ayomoy (1988), the urban drama series Kothao Keu Nei (1990), Nokkhotrer Raat (1996), and Aaj Robibar (1999). In addition, he made single episode dramas, most notably Nimful (1997) and Badol Diner Prothom Kodom Ful. Recurring characters in dramas directed and screenplayed by him are Tara Tin Jon and Alauddiner Cherager Doitto.
<br><br>
Ahmed directed films based on his own stories. His first film, Aguner Poroshmoni (1994), based on the Bangladesh Liberation War, won the 19th Bangladesh National Film Awards in a total of eight categories, including the awards for the Best Film and the Best Director. Another film Shyamal Chhaya (2005) was also based on the same war. His last directed film, Ghetuputra Kamola (2012), the story of a teenage boy, was set in the British colonial period.
<br><br>
Shyamol Chhaya and Ghetuputra Kamola were selected as the Bangladeshi entries for the Academy Award for Best Foreign Language Film in 2006 and 2012 respectively, but were not nominated.

In 2009, Ahmed appeared as one of two judges for the reality television music competition show Khudey Gaanraaj.


<br><br><br>
<h3 style="color:#641016">Awards And Achievements :</h3>
Exim Bank, a commercial bank and Anyadin, an entertainment magazine jointly introduced an award program, Humayun Ahmed Sahitya Puruskar, which would be conferred to two writers every year on Ahmed's birth anniversary – 12 November.

Several cinematographic adaptations of Ahmed's stories are made after his death. Anil Bagchir Ekdin (2015), directed by Morshedul Islam, won six Bangladesh National Film Awards. Krishnopokkho (2016) was directed by Meher Afroz Shaon. In October 2016, she announced the production of her next film based on Nokkhotrer Raat. Debi (2018) is produced by a grant from the Government of Bangladesh.<br><br><br>
<h3 style="color:#641016">Death :</h3>
Ahmed had open-heart surgery at Mount Elizabeth Hospital in Singapore. A few years later, during a routine checkup, doctors found a cancerous tumor in his colon. On 14 September 2011, he was flown to Memorial Sloan–Kettering Cancer Center in New York City for treatment. During his stay there, he wrote the novel, Deyal, based on the life of Sheikh Mujibur Rahman and Ziaur Rahman after the period of Bangladesh Liberation War. In January 2012, he was appointed as a senior special adviser of the Bangladesh Mission to the United Nations.
<br><br>
On 12 May 2012, Ahmed returned to Bangladesh for two weeks. He died on 19 July 2012 at 11:20 PM BST at Bellevue Hospital in New York City. There was some tension in the family over the selection of his burial site, but eventually his estate, Nuhash Palli was selected.
</div>
  </div>
  <div class="tab-pane fade" id="nav-novel" role="tabpanel" aria-labelledby="nav-novel-tab">

<?php

if(isset($_POST['search']))
{
    $valueToSearch = $_POST['valueToSearch'];
    // search in all table columns
    // using concat mysql function
    $query = "SELECT * FROM `humnovel` WHERE CONCAT( `name`, `writer`, `category`,`description`,`link`) LIKE '%".$valueToSearch."%'";
    $search_result = filterTable($query);
    
}
 else {
    $query = "SELECT * FROM `humnovel`";
    $search_result = filterTable($query);
}

// function to connect and execute the query
function filterTable($query)
{
    $connect = mysqli_connect("localhost", "root", "", "blog");
    $filter_Result = mysqli_query($connect, $query);
    return $filter_Result;
}

?>

 <form action="humayun.php" method="post"> 
            <br><br>
             <table style="border: 2px solid #641016;" class="text-white text-center">
                <tr class="mx-4 ml-4 my-4">
                   
                    <th class="mr-4 ml-4 my-4">Name</th>
                    <th class="mr-4 ml-4 my-4">Writer</th>
                    <th class="mr-4 ml-4 my-4">Category</th>
                    <th class="corner wideRow">Description</th>
                    <th class="mr-4 ml-4 my-4">Link</th>
                </tr>

      <!-- populate table from mysql database -->
                <?php while($row = mysqli_fetch_array($search_result)):?>
                <tr class="mr-4 ml-4 my-4">
                    
                    <td style="font-weight: bolder" class="mr-4 ml-4 my-4"><?php echo $row['name'];?></td>
                    <td class="mr-4 ml-4 my-4"><?php echo $row['writer'];?></td>
                    <td class="mr-4 ml-4 my-4"><?php echo $row['category'];?></td>
                     <td class="mr-4 ml-4 my-4"><?php echo $row['description'];?></td>
                      <td class="mr-4 ml-4 my-4"><?php echo $row['link'];?></td>
                </tr>
                <?php endwhile;?>
            </table>
        </form>
  </div>

  <div class="tab-pane fade" id="nav-sc" role="tabpanel" aria-labelledby="nav-sc-tab">

<?php

if(isset($_POST['search']))
{
    $valueToSearch = $_POST['valueToSearch'];
    // search in all table columns
    // using concat mysql function
    $query = "SELECT * FROM `humayunsc` WHERE CONCAT( `name`, `writer`, `category`,`description`,`link`) LIKE '%".$valueToSearch."%'";
    $search_result = filterTable2($query);
    
}
 else {
    $query = "SELECT * FROM `humayunsc`";
    $search_result = filterTable2($query);
}

// function to connect and execute the query
function filterTable2($query)
{
    $connect = mysqli_connect("localhost", "root", "", "blog");
    $filter_Result = mysqli_query($connect, $query);
    return $filter_Result;
}

?>

 <form action="humayun.php" method="post"> 
            <br><br>
             <table style="border: 2px solid #641016;" class="text-white text-center">
                <tr class="mx-4 ml-4 my-4">
                   
                    <th class="mr-4 ml-4 my-4">Name</th>
                    <th class="mr-4 ml-4 my-4">Writer</th>
                    <th class="mr-4 ml-4 my-4">Category</th>
                    <th class="corner wideRow">Description</th>
                    <th class="mr-4 ml-4 my-4">Link</th>
                </tr>

      <!-- populate table from mysql database -->
                <?php while($row = mysqli_fetch_array($search_result)):?>
                <tr class="mr-4 ml-4 my-4">
                    
                    <td style="font-weight: bolder" class="mr-4 ml-4 my-4"><?php echo $row['name'];?></td>
                    <td class="mr-4 ml-4 my-4"><?php echo $row['writer'];?></td>
                    <td class="mr-4 ml-4 my-4"><?php echo $row['category'];?></td>
                     <td class="mr-4 ml-4 my-4"><?php echo $row['description'];?></td>
                      <td class="mr-4 ml-4 my-4"><?php echo $row['link'];?></td>
                </tr>
                <?php endwhile;?>
            </table>
        </form>
  </div>


   <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/4.5.0/js/bootstrap.bundle.min.js"></script>
  
</main>
</div>
</body>